package com.peroah.notification;

import com.peroah.PeroAH;
import com.peroah.config.ConfigManager;
import com.peroah.config.Messages;
import com.peroah.util.Money;
import com.peroah.util.Text;
import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.UUID;

public final class NotificationManager {
    private final PeroAH plugin;
    private final ConfigManager config;
    private final Messages messages;

    public NotificationManager(PeroAH plugin, ConfigManager config, Messages messages) {
        this.plugin = plugin;
        this.config = config;
        this.messages = messages;
    }

    public void outbid(UUID player, ItemStack item, double oldBid, double newBid) {
        if (!config.notifyOutbid()) {
            return;
        }
        send(player, messages.get("bidwar.outbid",
                Text.ph("item", Text.itemName(item)),
                Text.ph("old", Money.format(oldBid, config.currencySymbol())),
                Text.ph("new", Money.format(newBid, config.currencySymbol()))));
    }

    public void won(UUID player, ItemStack item, double price) {
        if (!config.notifyWon()) {
            return;
        }
        send(player, messages.get("bidwar.won",
                Text.ph("item", Text.itemName(item)),
                Text.ph("price", Money.format(price, config.currencySymbol()))));
    }

    public void sold(UUID player, ItemStack item, double price) {
        if (!config.notifySold()) {
            return;
        }
        send(player, messages.get("auction.sold",
                Text.ph("item", Text.itemName(item)),
                Text.ph("price", Money.format(price, config.currencySymbol()))));
    }

    public void expired(UUID player, ItemStack item) {
        if (!config.notifyExpired()) {
            return;
        }
        send(player, messages.get("auction.expired", Text.ph("item", Text.itemName(item))));
    }

    public void mailWaiting(Player player, int count) {
        if (count <= 0) {
            return;
        }
        player.sendMessage(messages.get("mail.received", Text.ph("count", String.valueOf(count))));
    }

    private void send(UUID id, Component message) {
        plugin.sync(() -> {
            Player player = Bukkit.getPlayer(id);
            if (player != null && player.isOnline()) {
                player.sendMessage(message);
            }
        });
    }
}
