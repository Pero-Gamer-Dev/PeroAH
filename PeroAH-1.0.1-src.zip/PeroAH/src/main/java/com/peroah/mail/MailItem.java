package com.peroah.mail;

import org.bukkit.inventory.ItemStack;

import java.util.UUID;

public final class MailItem {
    private long id;
    private UUID playerId;
    private MailType type;
    private ItemStack item;
    private double money;
    private String message;
    private boolean claimed;
    private long createdAt;
    private Long auctionId;

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public UUID getPlayerId() {
        return playerId;
    }

    public void setPlayerId(UUID playerId) {
        this.playerId = playerId;
    }

    public MailType getType() {
        return type;
    }

    public void setType(MailType type) {
        this.type = type;
    }

    public ItemStack getItem() {
        return item == null ? null : item.clone();
    }

    public void setItem(ItemStack item) {
        this.item = item == null ? null : item.clone();
    }

    public double getMoney() {
        return money;
    }

    public void setMoney(double money) {
        this.money = money;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public boolean isClaimed() {
        return claimed;
    }

    public void setClaimed(boolean claimed) {
        this.claimed = claimed;
    }

    public long getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(long createdAt) {
        this.createdAt = createdAt;
    }

    public Long getAuctionId() {
        return auctionId;
    }

    public void setAuctionId(Long auctionId) {
        this.auctionId = auctionId;
    }
}
