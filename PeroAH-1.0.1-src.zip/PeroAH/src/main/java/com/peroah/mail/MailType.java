package com.peroah.mail;

public enum MailType {
    PURCHASED_ITEM,
    AUCTION_EARNINGS,
    OUTBID_REFUND,
    EXPIRED_AUCTION,
    BIDWAR_WON,
    CANCELLED_ITEM,
    ADMIN_RETURN
}
