package com.peroah.mail;

import com.peroah.storage.MailRepository;
import com.peroah.util.Text;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.sql.SQLException;
import java.util.List;
import java.util.UUID;

public final class MailManager {
    private final MailRepository repository;

    public MailManager(MailRepository repository) {
        this.repository = repository;
    }

    public MailItem sendItem(UUID player, MailType type, ItemStack item, String message, Long auctionId) throws SQLException {
        MailItem mail = new MailItem();
        mail.setPlayerId(player);
        mail.setType(type);
        mail.setItem(item);
        mail.setMoney(0);
        mail.setMessage(message);
        mail.setCreatedAt(System.currentTimeMillis());
        mail.setAuctionId(auctionId);
        return repository.insert(mail);
    }

    public MailItem sendMoney(UUID player, MailType type, double money, String message, Long auctionId) throws SQLException {
        MailItem mail = new MailItem();
        mail.setPlayerId(player);
        mail.setType(type);
        mail.setMoney(money);
        mail.setMessage(message);
        mail.setCreatedAt(System.currentTimeMillis());
        mail.setAuctionId(auctionId);
        return repository.insert(mail);
    }

    public List<MailItem> unclaimed(UUID player) throws SQLException {
        return repository.findUnclaimed(player);
    }

    public int count(UUID player) throws SQLException {
        return repository.countUnclaimed(player);
    }

    public MailItem get(long id) throws SQLException {
        return repository.findById(id);
    }

    /**
     * Atomically marks claimed. Caller must then deliver item/money.
     */
    public boolean markClaimed(long id) throws SQLException {
        return repository.markClaimed(id);
    }

    public boolean giveOrFail(Player player, ItemStack item) {
        if (item == null) {
            return true;
        }
        if (player.getInventory().firstEmpty() == -1 && !canStackInto(player, item)) {
            return false;
        }
        player.getInventory().addItem(item.clone());
        return true;
    }

    private boolean canStackInto(Player player, ItemStack item) {
        int left = item.getAmount();
        for (ItemStack content : player.getInventory().getStorageContents()) {
            if (content == null || content.getType().isAir()) {
                return true;
            }
            if (content.isSimilar(item)) {
                left -= content.getMaxStackSize() - content.getAmount();
                if (left <= 0) {
                    return true;
                }
            }
        }
        return false;
    }

    public String typeLabel(MailType type) {
        return switch (type) {
            case PURCHASED_ITEM -> "Purchased Item";
            case AUCTION_EARNINGS -> "Auction Earnings";
            case OUTBID_REFUND -> "Outbid Refund";
            case EXPIRED_AUCTION -> "Expired Auction";
            case BIDWAR_WON -> "BidWar Won";
            case CANCELLED_ITEM -> "Cancelled Listing";
            case ADMIN_RETURN -> "Returned by Admin";
        };
    }

    public String itemLabel(ItemStack item) {
        return item == null ? "—" : Text.itemNamePlain(item);
    }
}
