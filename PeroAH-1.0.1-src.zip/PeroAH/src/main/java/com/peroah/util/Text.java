package com.peroah.util;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.text.minimessage.MiniMessage;
import net.kyori.adventure.text.minimessage.tag.resolver.Placeholder;
import net.kyori.adventure.text.minimessage.tag.resolver.TagResolver;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;
import org.bukkit.inventory.ItemStack;

public final class Text {
    private static final MiniMessage MM = MiniMessage.miniMessage();
    private static final PlainTextComponentSerializer PLAIN = PlainTextComponentSerializer.plainText();
    private static final LegacyComponentSerializer LEGACY = LegacyComponentSerializer.legacySection();

    private Text() {}

    public static Component mm(String input) {
        if (input == null || input.isEmpty()) {
            return Component.empty();
        }
        return MM.deserialize(input).decoration(TextDecoration.ITALIC, false);
    }

    public static Component mm(String input, TagResolver... resolvers) {
        return MM.deserialize(input == null ? "" : input, resolvers).decoration(TextDecoration.ITALIC, false);
    }

    public static TagResolver ph(String key, String value) {
        return Placeholder.unparsed(key, value == null ? "" : value);
    }

    public static TagResolver ph(String key, Component value) {
        return Placeholder.component(key, value);
    }

    public static String plain(Component component) {
        return PLAIN.serialize(component == null ? Component.empty() : component);
    }

    public static Component itemName(ItemStack stack) {
        if (stack == null || stack.getType().isAir()) {
            return Component.text("Air", NamedTextColor.GRAY);
        }
        if (stack.hasItemMeta() && stack.getItemMeta().hasDisplayName()) {
            return stack.getItemMeta().displayName().decoration(TextDecoration.ITALIC, false);
        }
        return Component.translatable(stack.getType().translationKey()).decoration(TextDecoration.ITALIC, false);
    }

    public static String itemNamePlain(ItemStack stack) {
        return plain(itemName(stack));
    }

    public static Component legacy(String sectionColored) {
        return LEGACY.deserialize(sectionColored == null ? "" : sectionColored)
                .decoration(TextDecoration.ITALIC, false);
    }

    public static Component noItalic(Component component) {
        return component.decoration(TextDecoration.ITALIC, false);
    }
}
