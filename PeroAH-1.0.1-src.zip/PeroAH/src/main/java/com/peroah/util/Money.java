package com.peroah.util;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.Locale;

public final class Money {
    private Money() {}

    public static double normalize(double amount) {
        return BigDecimal.valueOf(amount).setScale(2, RoundingMode.HALF_UP).doubleValue();
    }

    public static boolean greaterOrEqual(double a, double b) {
        return Double.compare(normalize(a), normalize(b)) >= 0;
    }

    public static String format(double amount, String symbol) {
        DecimalFormatSymbols symbols = DecimalFormatSymbols.getInstance(Locale.US);
        DecimalFormat format = new DecimalFormat("#,##0.00", symbols);
        return symbol + format.format(normalize(amount));
    }

    public static Double parse(String raw) {
        if (raw == null) {
            return null;
        }
        String cleaned = raw.trim().replace(",", "").replace("$", "");
        try {
            double value = Double.parseDouble(cleaned);
            if (!Double.isFinite(value) || value < 0) {
                return null;
            }
            return normalize(value);
        } catch (NumberFormatException ex) {
            return null;
        }
    }
}
