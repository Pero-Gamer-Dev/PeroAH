package com.peroah.util;

import java.util.Locale;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class TimeUtil {
    private static final Pattern TOKEN = Pattern.compile("(\\d+)\\s*([smhd])", Pattern.CASE_INSENSITIVE);

    private TimeUtil() {}

    public static long now() {
        return System.currentTimeMillis();
    }

    public static String formatRemaining(long expiresAt) {
        long remaining = Math.max(0, expiresAt - now());
        return formatDuration(remaining);
    }

    public static String formatDuration(long millis) {
        long seconds = Math.max(0, millis / 1000);
        long days = TimeUnit.SECONDS.toDays(seconds);
        seconds -= TimeUnit.DAYS.toSeconds(days);
        long hours = TimeUnit.SECONDS.toHours(seconds);
        seconds -= TimeUnit.HOURS.toSeconds(hours);
        long minutes = TimeUnit.SECONDS.toMinutes(seconds);
        seconds -= TimeUnit.MINUTES.toSeconds(minutes);
        if (days > 0) {
            return days + "d " + hours + "h";
        }
        if (hours > 0) {
            return hours + "h " + minutes + "m";
        }
        if (minutes > 0) {
            return minutes + "m " + seconds + "s";
        }
        return seconds + "s";
    }

    /**
     * Parses 30s, 15m, 2h, 1d, or a raw second count.
     */
    public static Long parseDurationSeconds(String raw) {
        if (raw == null || raw.isBlank()) {
            return null;
        }
        String value = raw.trim().toLowerCase(Locale.ROOT);
        try {
            if (value.chars().allMatch(Character::isDigit)) {
                return Long.parseLong(value);
            }
            Matcher matcher = TOKEN.matcher(value);
            long total = 0;
            boolean found = false;
            while (matcher.find()) {
                found = true;
                long amount = Long.parseLong(matcher.group(1));
                total += switch (matcher.group(2).charAt(0)) {
                    case 's' -> amount;
                    case 'm' -> amount * 60;
                    case 'h' -> amount * 3600;
                    case 'd' -> amount * 86400;
                    default -> 0;
                };
            }
            return found ? total : null;
        } catch (NumberFormatException ex) {
            return null;
        }
    }
}
