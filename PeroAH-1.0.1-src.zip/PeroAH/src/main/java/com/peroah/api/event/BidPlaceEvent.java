package com.peroah.api.event;

import com.peroah.auction.Auction;
import org.bukkit.event.Cancellable;
import org.bukkit.event.Event;
import org.bukkit.event.HandlerList;
import org.jetbrains.annotations.NotNull;

import java.util.UUID;

public final class BidPlaceEvent extends Event implements Cancellable {
    private static final HandlerList HANDLERS = new HandlerList();
    private final Auction auction;
    private final UUID bidder;
    private final double amount;
    private boolean cancelled;

    public BidPlaceEvent(Auction auction, UUID bidder, double amount) {
        super(true);
        this.auction = auction;
        this.bidder = bidder;
        this.amount = amount;
    }

    public Auction getAuction() {
        return auction;
    }

    public UUID getBidder() {
        return bidder;
    }

    public double getAmount() {
        return amount;
    }

    @Override
    public boolean isCancelled() {
        return cancelled;
    }

    @Override
    public void setCancelled(boolean cancel) {
        this.cancelled = cancel;
    }

    @Override
    public @NotNull HandlerList getHandlers() {
        return HANDLERS;
    }

    public static HandlerList getHandlerList() {
        return HANDLERS;
    }
}
