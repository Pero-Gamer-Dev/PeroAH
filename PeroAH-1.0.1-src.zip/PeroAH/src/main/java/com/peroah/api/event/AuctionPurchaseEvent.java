package com.peroah.api.event;

import com.peroah.auction.Auction;
import org.bukkit.event.Event;
import org.bukkit.event.HandlerList;
import org.jetbrains.annotations.NotNull;

import java.util.UUID;

public final class AuctionPurchaseEvent extends Event {
    private static final HandlerList HANDLERS = new HandlerList();
    private final Auction auction;
    private final UUID buyer;

    public AuctionPurchaseEvent(Auction auction, UUID buyer) {
        super(true);
        this.auction = auction;
        this.buyer = buyer;
    }

    public Auction getAuction() {
        return auction;
    }

    public UUID getBuyer() {
        return buyer;
    }

    @Override
    public @NotNull HandlerList getHandlers() {
        return HANDLERS;
    }

    public static HandlerList getHandlerList() {
        return HANDLERS;
    }
}
