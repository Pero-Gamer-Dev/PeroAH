package com.peroah.api.event;

import com.peroah.auction.Auction;
import org.bukkit.event.Event;
import org.bukkit.event.HandlerList;
import org.jetbrains.annotations.NotNull;

public final class AuctionCancelEvent extends Event {
    private static final HandlerList HANDLERS = new HandlerList();
    private final Auction auction;

    public AuctionCancelEvent(Auction auction) {
        super(true);
        this.auction = auction;
    }

    public Auction getAuction() {
        return auction;
    }

    @Override
    public @NotNull HandlerList getHandlers() {
        return HANDLERS;
    }

    public static HandlerList getHandlerList() {
        return HANDLERS;
    }
}
