package com.peroah.api.event;

import com.peroah.auction.Auction;
import org.bukkit.event.Event;
import org.bukkit.event.HandlerList;
import org.jetbrains.annotations.NotNull;

import java.util.UUID;

public final class BidWarEndEvent extends Event {
    private static final HandlerList HANDLERS = new HandlerList();
    private final Auction auction;
    private final UUID winner;

    public BidWarEndEvent(Auction auction, UUID winner) {
        super(true);
        this.auction = auction;
        this.winner = winner;
    }

    public Auction getAuction() {
        return auction;
    }

    public UUID getWinner() {
        return winner;
    }

    @Override
    public @NotNull HandlerList getHandlers() {
        return HANDLERS;
    }

    public static HandlerList getHandlerList() {
        return HANDLERS;
    }
}
