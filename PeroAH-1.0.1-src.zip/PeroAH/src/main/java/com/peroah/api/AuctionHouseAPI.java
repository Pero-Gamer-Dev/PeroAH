package com.peroah.api;

import com.peroah.auction.Auction;
import com.peroah.auction.AuctionManager;
import com.peroah.auction.AuctionType;
import com.peroah.bidding.Bid;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.List;

public final class AuctionHouseAPI {
    private static AuctionHouseAPI instance;
    private final AuctionManager auctions;

    public AuctionHouseAPI(AuctionManager auctions) {
        this.auctions = auctions;
        instance = this;
    }

    public static AuctionHouseAPI getInstance() {
        return instance;
    }

    public Auction createListing(Player seller, ItemStack item, double price, long durationSeconds) {
        AuctionManager.Outcome result = auctions.createListing(seller, item, AuctionType.FIXED_PRICE, price, 0, durationSeconds);
        if (result != AuctionManager.Outcome.OK) {
            return null;
        }
        return auctions.liveListings().stream()
                .filter(a -> a.isSeller(seller.getUniqueId()) && a.getType() == AuctionType.FIXED_PRICE)
                .reduce((first, second) -> second)
                .orElse(null);
    }

    public Auction createBidWar(Player seller, ItemStack item, double start, double increment, long durationSeconds) {
        AuctionManager.Outcome result = auctions.createListing(seller, item, AuctionType.BIDWAR, start, increment, durationSeconds);
        if (result != AuctionManager.Outcome.OK) {
            return null;
        }
        return auctions.liveListings().stream()
                .filter(a -> a.isSeller(seller.getUniqueId()) && a.isBidWar())
                .reduce((first, second) -> second)
                .orElse(null);
    }

    public Auction getListing(long id) {
        return auctions.get(id);
    }

    public boolean cancelListing(Player actor, long id, boolean admin) {
        return auctions.cancel(actor, id, admin) == AuctionManager.Outcome.OK;
    }

    public List<Auction> getActiveListings() {
        return auctions.liveListings();
    }

    public AuctionManager.Outcome placeBid(Player player, long auctionId, double amount) {
        return auctions.placeBid(player, auctionId, amount);
    }

    public Double getHighestBid(long auctionId) {
        Auction auction = auctions.get(auctionId);
        return auction == null ? null : auction.getCurrentPrice();
    }

    public List<Bid> getBidHistory(long auctionId) {
        return auctions.history(auctionId);
    }
}
