package com.peroah.gui;

import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.jetbrains.annotations.NotNull;

import java.util.HashMap;
import java.util.Map;
import java.util.function.Consumer;

public final class GuiHolder implements InventoryHolder {
    public enum Kind {
        MAIN, BIDWARS, VIEW, SELL, MY_AUCTIONS, CLAIM, CONFIRM, SEARCH_HINT
    }

    private final Kind kind;
    private Inventory inventory;
    private int page;
    private long auctionId;
    private String query = "";
    private final Map<Integer, Consumer<Click>> actions = new HashMap<>();

    public GuiHolder(Kind kind) {
        this.kind = kind;
    }

    public Kind kind() {
        return kind;
    }

    public void attach(Inventory inventory) {
        this.inventory = inventory;
    }

    @Override
    public @NotNull Inventory getInventory() {
        return inventory;
    }

    public int page() {
        return page;
    }

    public void setPage(int page) {
        this.page = Math.max(0, page);
    }

    public long auctionId() {
        return auctionId;
    }

    public void setAuctionId(long auctionId) {
        this.auctionId = auctionId;
    }

    public String query() {
        return query;
    }

    public void setQuery(String query) {
        this.query = query == null ? "" : query;
    }

    public void action(int slot, Consumer<Click> click) {
        actions.put(slot, click);
    }

    public void handle(Click click) {
        Consumer<Click> consumer = actions.get(click.slot());
        if (consumer != null) {
            consumer.accept(click);
        }
    }

    public record Click(org.bukkit.entity.Player player, int slot, boolean right, boolean shift) {}
}
