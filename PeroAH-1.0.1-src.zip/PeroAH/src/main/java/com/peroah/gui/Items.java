package com.peroah.gui;

import com.peroah.util.Text;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Material;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public final class Items {
    private Items() {}

    public static ItemStack named(Material material, String miniName, String... miniLore) {
        ItemStack stack = new ItemStack(material);
        ItemMeta meta = stack.getItemMeta();
        meta.displayName(Text.mm(miniName).decoration(TextDecoration.ITALIC, false));
        if (miniLore.length > 0) {
            List<Component> lore = new ArrayList<>();
            for (String line : miniLore) {
                lore.add(Text.mm(line).decoration(TextDecoration.ITALIC, false));
            }
            meta.lore(lore);
        }
        stack.setItemMeta(meta);
        return stack;
    }

    public static ItemStack filler() {
        ItemStack stack = new ItemStack(Material.GRAY_STAINED_GLASS_PANE);
        ItemMeta meta = stack.getItemMeta();
        meta.displayName(Component.text(" ").decoration(TextDecoration.ITALIC, false));
        stack.setItemMeta(meta);
        return stack;
    }

    public static ItemStack withLore(ItemStack base, Component name, List<Component> lore) {
        ItemStack stack = base.clone();
        ItemMeta meta = stack.getItemMeta();
        if (name != null) {
            meta.displayName(name.decoration(TextDecoration.ITALIC, false));
        }
        List<Component> cleaned = new ArrayList<>();
        for (Component line : lore) {
            cleaned.add(line.decoration(TextDecoration.ITALIC, false));
        }
        meta.lore(cleaned);
        stack.setItemMeta(meta);
        return stack;
    }

    public static List<Component> lore(Component... lines) {
        return Arrays.asList(lines);
    }

    public static Component gray(String text) {
        return Component.text(text, NamedTextColor.GRAY).decoration(TextDecoration.ITALIC, false);
    }
}
