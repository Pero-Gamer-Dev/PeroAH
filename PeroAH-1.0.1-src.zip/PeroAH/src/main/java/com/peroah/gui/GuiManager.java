package com.peroah.gui;

import com.peroah.PeroAH;
import com.peroah.auction.Auction;
import com.peroah.auction.AuctionManager;
import com.peroah.auction.AuctionStatus;
import com.peroah.auction.AuctionType;
import com.peroah.bidding.Bid;
import com.peroah.config.ConfigManager;
import com.peroah.config.Messages;
import com.peroah.economy.EconomyService;
import com.peroah.item.ItemCategory;
import com.peroah.mail.MailItem;
import com.peroah.mail.MailManager;
import com.peroah.util.Money;
import com.peroah.util.Text;
import com.peroah.util.TimeUtil;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Consumer;

public final class GuiManager {
    private static final int[] LISTING_SLOTS = {
            10, 11, 12, 13, 14, 15, 16,
            19, 20, 21, 22, 23, 24, 25,
            28, 29, 30, 31, 32, 33, 34,
            37, 38, 39, 40, 41, 42, 43
    };

    private final PeroAH plugin;
    private final AuctionManager auctions;
    private final ConfigManager config;
    private final Messages messages;
    private final EconomyService economy;
    private final MailManager mail;
    private final Map<UUID, Consumer<String>> prompts = new ConcurrentHashMap<>();
    private final Map<UUID, AuctionManager.Sort> sorts = new ConcurrentHashMap<>();
    private final Map<UUID, ItemCategory> categories = new ConcurrentHashMap<>();

    public GuiManager(PeroAH plugin, AuctionManager auctions, ConfigManager config,
                      Messages messages, EconomyService economy, MailManager mail) {
        this.plugin = plugin;
        this.auctions = auctions;
        this.config = config;
        this.messages = messages;
        this.economy = economy;
        this.mail = mail;
    }

    public boolean handlePrompt(Player player, String message) {
        Consumer<String> prompt = prompts.remove(player.getUniqueId());
        if (prompt == null) {
            return false;
        }
        if (message.equalsIgnoreCase("cancel")) {
            messages.send(player, "general.cancelled-input");
            return true;
        }
        prompt.accept(message);
        return true;
    }

    public void openMain(Player player, int page, String query) {
        GuiHolder holder = new GuiHolder(GuiHolder.Kind.MAIN);
        holder.setPage(page);
        holder.setQuery(query);
        Inventory inv = Bukkit.createInventory(holder, 54, Text.mm("<gold><bold>PeroAH</bold></gold> <dark_gray>Auction House"));
        holder.attach(inv);
        fillFrame(inv);

        AuctionManager.Sort sort = sorts.getOrDefault(player.getUniqueId(), AuctionManager.Sort.NEWEST);
        ItemCategory category = categories.getOrDefault(player.getUniqueId(), ItemCategory.ALL);
        List<Auction> list = auctions.search(query, null, sort).stream()
                .filter(a -> category.matches(a.getItemView()))
                .toList();
        paintListings(player, holder, inv, list, page, click -> openView(click.player(), clickAuction(list, page, click.slot())));

        inv.setItem(45, Items.named(Material.HOPPER, "<aqua>Search",
                "<gray>Click and type in chat.", "<dark_gray>Current: <white>" + (query.isEmpty() ? "none" : query)));
        holder.action(45, click -> {
            click.player().closeInventory();
            click.player().sendMessage(Text.mm("<gold>Type a search query in chat, or <white>cancel</white>."));
            prompts.put(click.player().getUniqueId(), raw -> plugin.sync(() -> openMain(click.player(), 0, raw)));
        });

        inv.setItem(46, Items.named(Material.COMPARATOR, "<yellow>Sort: <white>" + pretty(sort.name()),
                "<gray>Click to cycle."));
        holder.action(46, click -> {
            sorts.put(player.getUniqueId(), nextSort(sort));
            openMain(player, 0, query);
        });

        inv.setItem(47, Items.named(Material.CHEST, "<yellow>Filter: <white>" + pretty(category.name()),
                "<gray>Click to cycle categories."));
        holder.action(47, click -> {
            categories.put(player.getUniqueId(), nextCategory(category));
            openMain(player, 0, query);
        });

        inv.setItem(49, Items.named(Material.EMERALD, "<green><bold>Sell Item",
                "<gray>List a held item", "<gray>or open the sell menu."));
        holder.action(49, click -> openSell(click.player()));

        inv.setItem(51, Items.named(Material.GOLDEN_SWORD, "<gold><bold>BidWars",
                "<gray>Competitive auctions."));
        holder.action(51, click -> openBidWars(click.player(), 0));

        inv.setItem(52, Items.named(Material.PLAYER_HEAD, "<aqua><bold>My Auctions",
                "<gray>Manage your listings."));
        holder.action(52, click -> openMine(click.player(), 0));

        inv.setItem(53, Items.named(Material.ENDER_CHEST, "<light_purple><bold>Auction Mail",
                "<gray>Claim items and earnings."));
        holder.action(53, click -> openClaim(click.player(), 0));

        player.openInventory(inv);
    }

    public void openBidWars(Player player, int page) {
        GuiHolder holder = new GuiHolder(GuiHolder.Kind.BIDWARS);
        holder.setPage(page);
        Inventory inv = Bukkit.createInventory(holder, 54, Text.mm("<gold><bold>PeroAH</bold></gold> <dark_gray>BidWars"));
        holder.attach(inv);
        fillFrame(inv);
        List<Auction> list = auctions.search("", AuctionType.BIDWAR, AuctionManager.Sort.ENDING_SOON);
        paintListings(player, holder, inv, list, page, click -> openView(click.player(), clickAuction(list, page, click.slot())));
        inv.setItem(49, Items.named(Material.ARROW, "<yellow>Back"));
        holder.action(49, click -> openMain(click.player(), 0, ""));
        player.openInventory(inv);
    }

    public void openView(Player player, Auction auction) {
        if (auction == null) {
            messages.send(player, "auction.not-found");
            return;
        }
        GuiHolder holder = new GuiHolder(GuiHolder.Kind.VIEW);
        holder.setAuctionId(auction.getId());
        Inventory inv = Bukkit.createInventory(holder, 45, Text.mm("<gold>Listing <white>#" + auction.getId()));
        holder.attach(inv);
        fillAll(inv);

        ItemStack display = listingIcon(auction, true);
        inv.setItem(13, display);

        List<Bid> history = auctions.history(auction.getId());
        inv.setItem(20, Items.named(Material.BOOK, "<yellow>Bid History",
                history.isEmpty() ? "<gray>No bids yet." : "<gray>" + history.size() + " bid(s)",
                history.isEmpty() ? "" : "<white>" + previewHistory(history)));

        if (auction.isBidWar()) {
            inv.setItem(24, Items.named(Material.GOLD_INGOT, "<gold><bold>Place Bid",
                    "<gray>Minimum: <white>" + money(auction.nextMinimumBid()),
                    "<gray>Click and type amount in chat."));
            holder.action(24, click -> {
                click.player().closeInventory();
                click.player().sendMessage(Text.mm("<gold>Type your bid amount, or <white>cancel</white>. Minimum: <white>"
                        + money(auction.nextMinimumBid())));
                prompts.put(click.player().getUniqueId(), raw -> {
                    Double parsed = Money.parse(raw);
                    if (parsed == null) {
                        messages.send(click.player(), "general.invalid-number");
                        return;
                    }
                    plugin.sync(() -> handleBidResult(click.player(), auctions.placeBid(click.player(), auction.getId(), parsed), auction, parsed));
                });
            });
        } else {
            inv.setItem(24, Items.named(Material.EMERALD_BLOCK, "<green><bold>Buy Now",
                    "<gray>Price: <white>" + money(auction.getCurrentPrice()),
                    "<gray>Click to purchase."));
            holder.action(24, click -> openConfirm(click.player(), auction));
        }

        if (auction.isSeller(player.getUniqueId()) || player.hasPermission("auctionhouse.admin")) {
            inv.setItem(40, Items.named(Material.BARRIER, "<red>Cancel Listing",
                    "<gray>Returns the item to Auction Mail."));
            holder.action(40, click -> {
                AuctionManager.Outcome result = auctions.cancel(click.player(), auction.getId(),
                        click.player().hasPermission("auctionhouse.admin") && !auction.isSeller(click.player().getUniqueId()));
                if (result == AuctionManager.Outcome.OK) {
                    messages.send(click.player(), "auction.cancelled", Text.ph("id", String.valueOf(auction.getId())));
                } else if (result == AuctionManager.Outcome.HAS_BIDS) {
                    click.player().sendMessage(Text.mm("<red>You cannot cancel a BidWar that already has bids."));
                } else {
                    messages.send(click.player(), "auction.not-found");
                }
                openMain(click.player(), 0, "");
            });
        }

        inv.setItem(44, Items.named(Material.ARROW, "<yellow>Back"));
        holder.action(44, click -> {
            if (auction.isBidWar()) {
                openBidWars(click.player(), 0);
            } else {
                openMain(click.player(), 0, "");
            }
        });
        player.openInventory(inv);
    }

    public void openConfirm(Player player, Auction auction) {
        GuiHolder holder = new GuiHolder(GuiHolder.Kind.CONFIRM);
        holder.setAuctionId(auction.getId());
        Inventory inv = Bukkit.createInventory(holder, 27, Text.mm("<red>Confirm Purchase"));
        holder.attach(inv);
        fillAll(inv);
        inv.setItem(13, listingIcon(auction, true));
        inv.setItem(11, Items.named(Material.LIME_CONCRETE, "<green><bold>CONFIRM",
                "<gray>Pay <white>" + money(auction.getCurrentPrice())));
        holder.action(11, click -> {
            AuctionManager.Outcome result = auctions.buy(click.player(), auction.getId());
            switch (result) {
                case OK -> messages.send(click.player(), "auction.purchased",
                        Text.ph("item", Text.itemName(auction.getItemView())),
                        Text.ph("price", money(auction.getCurrentPrice())));
                case CANNOT_AFFORD -> messages.send(click.player(), "auction.cannot-afford",
                        Text.ph("price", money(auction.getCurrentPrice())));
                case OWN_LISTING -> messages.send(click.player(), "auction.cannot-buy-own");
                case EXPIRED, NOT_FOUND, NOT_ACTIVE -> messages.send(click.player(), "auction.already-gone");
                case NO_ECONOMY -> messages.send(click.player(), "general.vault-missing");
                default -> messages.send(click.player(), "auction.not-found");
            }
            click.player().closeInventory();
        });
        inv.setItem(15, Items.named(Material.RED_CONCRETE, "<red><bold>CANCEL"));
        holder.action(15, click -> openView(click.player(), auctions.getLive(auction.getId())));
        player.openInventory(inv);
    }

    public void openSell(Player player) {
        GuiHolder holder = new GuiHolder(GuiHolder.Kind.SELL);
        Inventory inv = Bukkit.createInventory(holder, 45, Text.mm("<green>Sell / Start BidWar"));
        holder.attach(inv);
        fillAll(inv);
        ItemStack hand = player.getInventory().getItemInMainHand();
        if (hand != null && !hand.getType().isAir()) {
            inv.setItem(13, hand.clone());
        } else {
            inv.setItem(13, Items.named(Material.ITEM_FRAME, "<yellow>Hold an item",
                    "<gray>Put the item you want to sell", "<gray>in your main hand, then reopen."));
        }
        inv.setItem(29, Items.named(Material.EMERALD, "<green><bold>Fixed Price",
                "<gray>Default duration: <white>" + TimeUtil.formatDuration(config.defaultDurationSeconds() * 1000),
                "<gray>Click, then type the price in chat."));
        holder.action(29, click -> promptSell(click.player(), AuctionType.FIXED_PRICE));
        inv.setItem(33, Items.named(Material.GOLD_INGOT, "<gold><bold>BidWar",
                "<gray>Starting bid + increment.",
                "<gray>Default length: <white>" + TimeUtil.formatDuration(config.bidWarDefaultDuration() * 1000)));
        holder.action(33, click -> promptSell(click.player(), AuctionType.BIDWAR));
        inv.setItem(40, Items.named(Material.ARROW, "<yellow>Back"));
        holder.action(40, click -> openMain(click.player(), 0, ""));
        player.openInventory(inv);
    }

    private void promptSell(Player player, AuctionType type) {
        ItemStack hand = player.getInventory().getItemInMainHand();
        if (hand == null || hand.getType().isAir()) {
            messages.send(player, "auction.no-item");
            return;
        }
        player.closeInventory();
        if (type == AuctionType.FIXED_PRICE) {
            player.sendMessage(Text.mm("<gold>Type the sell price, optionally followed by duration (e.g. <white>50000 24h</white>)."));
            prompts.put(player.getUniqueId(), raw -> plugin.sync(() -> createFromChat(player, AuctionType.FIXED_PRICE, raw)));
        } else {
            player.sendMessage(Text.mm("<gold>Type <white>start increment [duration]</white> e.g. <white>1000 100 30m</white>."));
            prompts.put(player.getUniqueId(), raw -> plugin.sync(() -> createFromChat(player, AuctionType.BIDWAR, raw)));
        }
    }

    public void createFromChat(Player player, AuctionType type, String raw) {
        String[] parts = raw.trim().split("\\s+");
        Double price = parts.length > 0 ? Money.parse(parts[0]) : null;
        if (price == null || price <= 0) {
            messages.send(player, "general.invalid-number");
            return;
        }
        ItemStack hand = player.getInventory().getItemInMainHand();
        if (type == AuctionType.FIXED_PRICE) {
            long duration = config.defaultDurationSeconds();
            if (parts.length > 1) {
                Long parsed = TimeUtil.parseDurationSeconds(parts[1]);
                if (parsed != null) {
                    duration = parsed;
                }
            }
            AuctionManager.Outcome result = auctions.createListing(player, hand, type, price, 0, duration);
            handleCreateResult(player, result, hand, price, type, duration);
        } else {
            double increment = config.bidWarDefaultIncrement();
            if (parts.length > 1) {
                Double inc = Money.parse(parts[1]);
                if (inc != null) {
                    increment = inc;
                }
            }
            long duration = config.bidWarDefaultDuration();
            if (parts.length > 2) {
                Long parsed = TimeUtil.parseDurationSeconds(parts[2]);
                if (parsed != null) {
                    duration = parsed;
                }
            }
            AuctionManager.Outcome result = auctions.createListing(player, hand, type, price, increment, duration);
            handleCreateResult(player, result, hand, price, type, duration);
        }
    }

    private void handleCreateResult(Player player, AuctionManager.Outcome result, ItemStack item, double price, AuctionType type, long duration) {
        switch (result) {
            case OK -> {
                String path = type == AuctionType.BIDWAR ? "auction.listed-bidwar" : "auction.listed-fixed";
                messages.send(player, path,
                        Text.ph("item", Text.itemName(item)),
                        Text.ph("price", money(price)),
                        Text.ph("duration", TimeUtil.formatDuration(duration * 1000)));
            }
            case BLACKLISTED -> messages.send(player, "auction.blacklisted");
            case MAX_LISTINGS -> messages.send(player, "auction.max-listings", Text.ph("max", String.valueOf(config.maxListings())));
            case CANNOT_AFFORD_FEE -> messages.send(player, "auction.listing-fee", Text.ph("price", money(config.listingFee())));
            case NO_ECONOMY -> messages.send(player, "general.vault-missing");
            case BIDWAR_DISABLED -> messages.send(player, "bidwar.disabled");
            case INVALID_ITEM -> messages.send(player, "auction.no-item");
            default -> player.sendMessage(Text.mm("<red>Could not create that listing."));
        }
    }

    private void handleBidResult(Player player, AuctionManager.Outcome result, Auction auction, double amount) {
        switch (result) {
            case OK -> messages.send(player, "bidwar.placed",
                    Text.ph("price", money(amount)),
                    Text.ph("item", Text.itemName(auction.getItemView())));
            case TOO_LOW -> messages.send(player, "bidwar.too-low", Text.ph("price", money(auction.nextMinimumBid())));
            case SELF_BID -> messages.send(player, "bidwar.cannot-bid-own");
            case CANNOT_AFFORD -> messages.send(player, "auction.cannot-afford", Text.ph("price", money(amount)));
            case NO_ECONOMY -> messages.send(player, "general.vault-missing");
            default -> messages.send(player, "auction.not-found");
        }
    }

    public void openMine(Player player, int page) {
        GuiHolder holder = new GuiHolder(GuiHolder.Kind.MY_AUCTIONS);
        holder.setPage(page);
        Inventory inv = Bukkit.createInventory(holder, 54, Text.mm("<aqua>My Auctions"));
        holder.attach(inv);
        fillFrame(inv);
        List<Auction> list = auctions.liveListings().stream()
                .filter(a -> a.isSeller(player.getUniqueId()))
                .toList();
        paintListings(player, holder, inv, list, page, click -> openView(click.player(), clickAuction(list, page, click.slot())));
        inv.setItem(49, Items.named(Material.ARROW, "<yellow>Back"));
        holder.action(49, click -> openMain(click.player(), 0, ""));
        player.openInventory(inv);
    }

    public void openClaim(Player player, int page) {
        GuiHolder holder = new GuiHolder(GuiHolder.Kind.CLAIM);
        holder.setPage(page);
        Inventory inv = Bukkit.createInventory(holder, 54, Text.mm("<light_purple>Auction Mail"));
        holder.attach(inv);
        fillFrame(inv);
        List<MailItem> items;
        try {
            items = mail.unclaimed(player.getUniqueId());
        } catch (SQLException ex) {
            items = List.of();
        }
        int per = LISTING_SLOTS.length;
        int from = page * per;
        for (int i = 0; i < per; i++) {
            int index = from + i;
            if (index >= items.size()) {
                break;
            }
            MailItem entry = items.get(index);
            int slot = LISTING_SLOTS[i];
            inv.setItem(slot, mailIcon(entry));
            holder.action(slot, click -> claimOne(click.player(), entry.getId()));
        }
        addPager(holder, inv, page, items.size(), per, p -> openClaim(player, p));
        inv.setItem(49, Items.named(Material.ARROW, "<yellow>Back"));
        holder.action(49, click -> openMain(click.player(), 0, ""));
        player.openInventory(inv);
    }

    private void claimOne(Player player, long mailId) {
        try {
            MailItem entry = mail.get(mailId);
            if (entry == null || entry.isClaimed() || !entry.getPlayerId().equals(player.getUniqueId())) {
                messages.send(player, "mail.empty");
                openClaim(player, 0);
                return;
            }
            if (entry.getItem() != null && !mail.giveOrFail(player, entry.getItem())) {
                messages.send(player, "mail.inventory-full");
                return;
            }
            if (!mail.markClaimed(mailId)) {
                if (entry.getItem() != null) {
                    // extremely unlikely race: item already given. Do not give money.
                }
                messages.send(player, "mail.empty");
                openClaim(player, 0);
                return;
            }
            if (entry.getMoney() > 0) {
                economy.deposit(player.getUniqueId(), entry.getMoney());
                messages.send(player, "mail.claimed-money", Text.ph("price", money(entry.getMoney())));
            }
            if (entry.getItem() != null) {
                messages.send(player, "mail.claimed-item", Text.ph("item", Text.itemName(entry.getItem())));
            }
        } catch (SQLException ex) {
            player.sendMessage(Text.mm("<red>Could not claim that mail."));
        }
        openClaim(player, 0);
    }

    private void paintListings(Player player, GuiHolder holder, Inventory inv, List<Auction> list, int page,
                               Consumer<GuiHolder.Click> onClick) {
        int per = LISTING_SLOTS.length;
        int from = page * per;
        for (int i = 0; i < per; i++) {
            int index = from + i;
            if (index >= list.size()) {
                inv.setItem(LISTING_SLOTS[i], null);
                continue;
            }
            Auction auction = list.get(index);
            int slot = LISTING_SLOTS[i];
            inv.setItem(slot, listingIcon(auction, false));
            holder.action(slot, onClick);
        }
        addPager(holder, inv, page, list.size(), per, p -> {
            if (holder.kind() == GuiHolder.Kind.MAIN) {
                openMain(player, p, holder.query());
            } else if (holder.kind() == GuiHolder.Kind.BIDWARS) {
                openBidWars(player, p);
            } else if (holder.kind() == GuiHolder.Kind.MY_AUCTIONS) {
                openMine(player, p);
            }
        });
    }

    private Auction clickAuction(List<Auction> list, int page, int slot) {
        int per = LISTING_SLOTS.length;
        for (int i = 0; i < per; i++) {
            if (LISTING_SLOTS[i] == slot) {
                int index = page * per + i;
                return index >= 0 && index < list.size() ? list.get(index) : null;
            }
        }
        return null;
    }

    private void addPager(GuiHolder holder, Inventory inv, int page, int total, int per, Consumer<Integer> opener) {
        int pages = Math.max(1, (int) Math.ceil(total / (double) per));
        if (page > 0) {
            inv.setItem(0, Items.named(Material.ARROW, "<yellow>Previous"));
            holder.action(0, click -> opener.accept(page - 1));
        }
        inv.setItem(8, Items.named(Material.PAPER, "<white>Page " + (page + 1) + "/" + pages,
                "<gray>" + total + " listing(s)"));
        if (page + 1 < pages) {
            inv.setItem(8, Items.named(Material.ARROW, "<yellow>Next  ·  " + (page + 1) + "/" + pages));
            holder.action(8, click -> opener.accept(page + 1));
        }
    }

    private ItemStack listingIcon(Auction auction, boolean detailed) {
        List<Component> lore = new ArrayList<>();
        lore.add(Component.text("Price: ", NamedTextColor.GRAY)
                .append(Component.text(money(auction.getCurrentPrice()), NamedTextColor.YELLOW))
                .decoration(TextDecoration.ITALIC, false));
        if (auction.isBidWar()) {
            lore.add(Component.text("Type: ", NamedTextColor.GRAY)
                    .append(Component.text("BidWar", NamedTextColor.GOLD)).decoration(TextDecoration.ITALIC, false));
            lore.add(Component.text("Next bid: ", NamedTextColor.GRAY)
                    .append(Component.text(money(auction.nextMinimumBid()), NamedTextColor.WHITE))
                    .decoration(TextDecoration.ITALIC, false));
            if (auction.getHighestBidder() != null) {
                lore.add(Component.text("Leader: ", NamedTextColor.GRAY)
                        .append(Component.text(nameOf(auction.getHighestBidder()), NamedTextColor.AQUA))
                        .decoration(TextDecoration.ITALIC, false));
            }
        } else {
            lore.add(Component.text("Type: ", NamedTextColor.GRAY)
                    .append(Component.text("Buy Now", NamedTextColor.GREEN)).decoration(TextDecoration.ITALIC, false));
        }
        lore.add(Component.text("Ends: ", NamedTextColor.GRAY)
                .append(Component.text(TimeUtil.formatRemaining(auction.getExpiresAt()), NamedTextColor.WHITE))
                .decoration(TextDecoration.ITALIC, false));
        lore.add(Component.text("Seller: ", NamedTextColor.GRAY)
                .append(Component.text(nameOf(auction.getSellerId()), NamedTextColor.AQUA))
                .decoration(TextDecoration.ITALIC, false));
        lore.add(Component.text("ID: #" + auction.getId(), NamedTextColor.DARK_GRAY).decoration(TextDecoration.ITALIC, false));
        if (detailed) {
            lore.add(Component.text("Status: " + auction.getStatus().name(), NamedTextColor.DARK_GRAY)
                    .decoration(TextDecoration.ITALIC, false));
        }
        lore.add(Component.empty());
        lore.add(Component.text("Click to open", NamedTextColor.YELLOW).decoration(TextDecoration.ITALIC, false));
        return Items.withLore(auction.getItem(), Text.itemName(auction.getItemView()), lore);
    }

    private ItemStack mailIcon(MailItem entry) {
        ItemStack base = entry.getItem() != null ? entry.getItem() : new ItemStack(Material.GOLD_NUGGET);
        List<Component> lore = new ArrayList<>();
        lore.add(Component.text(mail.typeLabel(entry.getType()), NamedTextColor.AQUA).decoration(TextDecoration.ITALIC, false));
        if (entry.getMoney() > 0) {
            lore.add(Component.text("Money: ", NamedTextColor.GRAY)
                    .append(Component.text(money(entry.getMoney()), NamedTextColor.YELLOW))
                    .decoration(TextDecoration.ITALIC, false));
        }
        lore.add(Component.text("Click to claim", NamedTextColor.YELLOW).decoration(TextDecoration.ITALIC, false));
        return Items.withLore(base, Text.itemName(base), lore);
    }

    private void fillFrame(Inventory inv) {
        ItemStack pane = Items.filler();
        for (int i = 0; i < inv.getSize(); i++) {
            if (i < 9 || i >= 45 || i % 9 == 0 || i % 9 == 8) {
                inv.setItem(i, pane);
            }
        }
    }

    private void fillAll(Inventory inv) {
        ItemStack pane = Items.filler();
        for (int i = 0; i < inv.getSize(); i++) {
            inv.setItem(i, pane);
        }
    }

    private String money(double amount) {
        return Money.format(amount, config.currencySymbol());
    }

    private String nameOf(UUID id) {
        String name = Bukkit.getOfflinePlayer(id).getName();
        return name == null ? id.toString().substring(0, 8) : name;
    }

    private String pretty(String raw) {
        String lower = raw.toLowerCase(Locale.ROOT).replace('_', ' ');
        return Character.toUpperCase(lower.charAt(0)) + lower.substring(1);
    }

    private String previewHistory(List<Bid> history) {
        StringBuilder builder = new StringBuilder();
        int shown = 0;
        for (Bid bid : history) {
            if (shown >= 5) {
                break;
            }
            if (shown > 0) {
                builder.append(", ");
            }
            builder.append(nameOf(bid.getBidderId())).append(" ").append(money(bid.getAmount()));
            shown++;
        }
        return builder.toString();
    }

    private AuctionManager.Sort nextSort(AuctionManager.Sort current) {
        AuctionManager.Sort[] values = AuctionManager.Sort.values();
        return values[(current.ordinal() + 1) % values.length];
    }

    private ItemCategory nextCategory(ItemCategory current) {
        ItemCategory[] values = ItemCategory.values();
        return values[(current.ordinal() + 1) % values.length];
    }

    public void handleClick(Player player, GuiHolder holder, int slot, boolean right, boolean shift) {
        holder.handle(new GuiHolder.Click(player, slot, right, shift));
    }
}
