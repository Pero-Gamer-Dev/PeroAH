package com.peroah.economy;

import java.util.UUID;

public interface EconomyService {
    boolean available();

    boolean has(UUID player, double amount);

    boolean withdraw(UUID player, double amount);

    boolean deposit(UUID player, double amount);

    double getBalance(UUID player);

    /**
     * Balance minus money currently reserved in BidWar escrow.
     */
    boolean hasAvailable(UUID player, double amount, double reserved);

    default boolean hasAvailable(UUID player, double amount) {
        return has(player, amount);
    }
}
