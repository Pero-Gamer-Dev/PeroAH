package com.peroah.economy;

import java.util.UUID;
import java.util.concurrent.atomic.AtomicReference;

/**
 * Swappable economy backend so Vault can be hooked after other plugins finish enabling.
 */
public final class EconomyHolder implements EconomyService {
    private final AtomicReference<EconomyService> delegate = new AtomicReference<>(new EmptyEconomyProvider());

    public void set(EconomyService service) {
        if (service != null) {
            delegate.set(service);
        }
    }

    public EconomyService current() {
        return delegate.get();
    }

    @Override
    public boolean available() {
        return delegate.get().available();
    }

    @Override
    public boolean has(UUID player, double amount) {
        return delegate.get().has(player, amount);
    }

    @Override
    public boolean withdraw(UUID player, double amount) {
        return delegate.get().withdraw(player, amount);
    }

    @Override
    public boolean deposit(UUID player, double amount) {
        return delegate.get().deposit(player, amount);
    }

    @Override
    public double getBalance(UUID player) {
        return delegate.get().getBalance(player);
    }

    @Override
    public boolean hasAvailable(UUID player, double amount, double reserved) {
        return delegate.get().hasAvailable(player, amount, reserved);
    }
}
