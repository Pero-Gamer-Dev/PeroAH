package com.peroah.economy;

import java.util.UUID;

/**
 * Used only so the plugin can still load without Vault; every money op fails.
 */
public final class EmptyEconomyProvider implements EconomyService {
    @Override
    public boolean available() {
        return false;
    }

    @Override
    public boolean has(UUID player, double amount) {
        return false;
    }

    @Override
    public boolean withdraw(UUID player, double amount) {
        return false;
    }

    @Override
    public boolean deposit(UUID player, double amount) {
        return false;
    }

    @Override
    public double getBalance(UUID player) {
        return 0;
    }

    @Override
    public boolean hasAvailable(UUID player, double amount, double reserved) {
        return false;
    }
}
