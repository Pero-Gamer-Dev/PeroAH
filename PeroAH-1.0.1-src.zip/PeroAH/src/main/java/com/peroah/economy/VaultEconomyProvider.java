package com.peroah.economy;

import net.milkbowl.vault.economy.Economy;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.plugin.RegisteredServiceProvider;

import java.util.UUID;

public final class VaultEconomyProvider implements EconomyService {
    private final Economy economy;

    public VaultEconomyProvider(Economy economy) {
        this.economy = economy;
    }

    public static VaultEconomyProvider hook() {
        if (Bukkit.getPluginManager().getPlugin("Vault") == null) {
            return null;
        }
        RegisteredServiceProvider<Economy> registration = Bukkit.getServicesManager().getRegistration(Economy.class);
        if (registration == null) {
            return null;
        }
        return new VaultEconomyProvider(registration.getProvider());
    }

    @Override
    public boolean available() {
        return economy != null;
    }

    @Override
    public boolean has(UUID player, double amount) {
        return economy.has(offline(player), amount);
    }

    @Override
    public boolean withdraw(UUID player, double amount) {
        return economy.withdrawPlayer(offline(player), amount).transactionSuccess();
    }

    @Override
    public boolean deposit(UUID player, double amount) {
        return economy.depositPlayer(offline(player), amount).transactionSuccess();
    }

    @Override
    public double getBalance(UUID player) {
        return economy.getBalance(offline(player));
    }

    @Override
    public boolean hasAvailable(UUID player, double amount, double reserved) {
        return getBalance(player) - reserved + 1e-9 >= amount;
    }

    private OfflinePlayer offline(UUID id) {
        return Bukkit.getOfflinePlayer(id);
    }
}
