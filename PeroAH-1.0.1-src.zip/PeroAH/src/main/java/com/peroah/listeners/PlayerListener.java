package com.peroah.listeners;

import com.peroah.gui.GuiManager;
import com.peroah.mail.MailManager;
import com.peroah.notification.NotificationManager;
import io.papermc.paper.event.player.AsyncChatEvent;
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;

import java.sql.SQLException;

public final class PlayerListener implements Listener {
    private final GuiManager guis;
    private final MailManager mail;
    private final NotificationManager notify;

    public PlayerListener(GuiManager guis, MailManager mail, NotificationManager notify) {
        this.guis = guis;
        this.mail = mail;
        this.notify = notify;
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        Player player = event.getPlayer();
        try {
            int count = mail.count(player.getUniqueId());
            if (count > 0) {
                notify.mailWaiting(player, count);
            }
        } catch (SQLException ignored) {
        }
    }

    @EventHandler(priority = EventPriority.LOWEST)
    public void onChat(AsyncChatEvent event) {
        String message = PlainTextComponentSerializer.plainText().serialize(event.message());
        if (guis.handlePrompt(event.getPlayer(), message)) {
            event.setCancelled(true);
        }
    }
}
