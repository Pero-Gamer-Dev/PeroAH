package com.peroah.bidding;

import com.peroah.auction.AuctionManager;
import org.bukkit.entity.Player;

import java.util.List;

/**
 * Facade over {@link AuctionManager} bid operations (escrow + history).
 */
public final class BidManager {
    private final AuctionManager auctions;

    public BidManager(AuctionManager auctions) {
        this.auctions = auctions;
    }

    public AuctionManager.Outcome place(Player player, long auctionId, double amount) {
        return auctions.placeBid(player, auctionId, amount);
    }

    public List<Bid> history(long auctionId) {
        return auctions.history(auctionId);
    }
}
