package com.peroah.bidding;

import com.peroah.auction.Auction;
import com.peroah.auction.AuctionType;
import com.peroah.util.Money;
import com.peroah.util.TimeUtil;

import java.util.UUID;

public final class BidValidator {
    public enum Result {
        OK,
        MISSING,
        NOT_BIDWAR,
        NOT_ACTIVE,
        EXPIRED,
        SELF_BID,
        TOO_LOW,
        INSUFFICIENT_FUNDS
    }

    public Result validate(Auction auction, UUID bidder, double amount, boolean canAfford) {
        if (auction == null) {
            return Result.MISSING;
        }
        if (auction.getType() != AuctionType.BIDWAR) {
            return Result.NOT_BIDWAR;
        }
        if (!auction.getStatus().isLive()) {
            return Result.NOT_ACTIVE;
        }
        if (auction.isExpired(TimeUtil.now())) {
            return Result.EXPIRED;
        }
        if (auction.isSeller(bidder)) {
            return Result.SELF_BID;
        }
        if (!Money.greaterOrEqual(amount, auction.nextMinimumBid())) {
            return Result.TOO_LOW;
        }
        if (!canAfford) {
            return Result.INSUFFICIENT_FUNDS;
        }
        return Result.OK;
    }
}
