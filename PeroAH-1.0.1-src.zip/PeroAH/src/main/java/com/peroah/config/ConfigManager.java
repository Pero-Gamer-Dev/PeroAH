package com.peroah.config;

import com.peroah.PeroAH;
import org.bukkit.configuration.file.FileConfiguration;

import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.stream.Collectors;

public final class ConfigManager {
    private final PeroAH plugin;
    private FileConfiguration cfg;

    public ConfigManager(PeroAH plugin) {
        this.plugin = plugin;
    }

    public void load() {
        plugin.saveDefaultConfig();
        plugin.reloadConfig();
        this.cfg = plugin.getConfig();
    }

    public int maxListings() {
        return cfg.getInt("settings.max-listings-per-player", 10);
    }

    public long defaultDurationSeconds() {
        return cfg.getLong("settings.default-duration", 86400);
    }

    public long minDurationSeconds() {
        return cfg.getLong("settings.min-duration", 60);
    }

    public long maxDurationSeconds() {
        return cfg.getLong("settings.max-duration", 604800);
    }

    public int listingsPerPage() {
        return cfg.getInt("settings.listings-per-page", 28);
    }

    public boolean allowSelfPurchase() {
        return cfg.getBoolean("settings.allow-self-purchase", false);
    }

    public String currencySymbol() {
        return cfg.getString("economy.currency-symbol", "$");
    }

    public boolean feesEnabled() {
        return cfg.getBoolean("fees.enabled", true);
    }

    public double listingFee() {
        return cfg.getDouble("fees.listing-fee", 0.0);
    }

    public double saleTaxPercent() {
        return cfg.getDouble("fees.sale-tax", 5.0);
    }

    public boolean bidWarEnabled() {
        return cfg.getBoolean("bidwar.enabled", true);
    }

    public long bidWarMinDuration() {
        return cfg.getLong("bidwar.minimum-duration", 60);
    }

    public long bidWarMaxDuration() {
        return cfg.getLong("bidwar.maximum-duration", 86400);
    }

    public long bidWarDefaultDuration() {
        return cfg.getLong("bidwar.default-duration", 1800);
    }

    public double bidWarMinIncrement() {
        return cfg.getDouble("bidwar.minimum-increment", 100.0);
    }

    public double bidWarDefaultIncrement() {
        return cfg.getDouble("bidwar.default-increment", 100.0);
    }

    public boolean antiSnipeEnabled() {
        return cfg.getBoolean("bidwar.anti-snipe.enabled", true);
    }

    public long antiSnipeTriggerMillis() {
        return cfg.getLong("bidwar.anti-snipe.trigger-seconds", 30) * 1000L;
    }

    public long antiSnipeExtensionMillis() {
        return cfg.getLong("bidwar.anti-snipe.extension-seconds", 30) * 1000L;
    }

    public String databaseType() {
        return cfg.getString("database.type", "SQLITE").toUpperCase(Locale.ROOT);
    }

    public String mysqlHost() {
        return cfg.getString("database.mysql.host", "localhost");
    }

    public int mysqlPort() {
        return cfg.getInt("database.mysql.port", 3306);
    }

    public String mysqlDatabase() {
        return cfg.getString("database.mysql.database", "auctionhouse");
    }

    public String mysqlUser() {
        return cfg.getString("database.mysql.username", "username");
    }

    public String mysqlPassword() {
        return cfg.getString("database.mysql.password", "password");
    }

    public int mysqlPoolSize() {
        return cfg.getInt("database.mysql.pool-size", 8);
    }

    public boolean notifyOutbid() {
        return cfg.getBoolean("notifications.outbid", true);
    }

    public boolean notifyWon() {
        return cfg.getBoolean("notifications.auction-won", true);
    }

    public boolean notifySold() {
        return cfg.getBoolean("notifications.auction-sold", true);
    }

    public boolean notifyExpired() {
        return cfg.getBoolean("notifications.auction-expired", true);
    }

    public Set<String> blacklistedMaterials() {
        List<String> list = cfg.getStringList("blacklist.materials");
        return list.stream().map(s -> s.toUpperCase(Locale.ROOT)).collect(Collectors.toCollection(HashSet::new));
    }

    public Set<Integer> blacklistedCustomModelData() {
        return new HashSet<>(cfg.getIntegerList("blacklist.custom-model-data"));
    }
}
