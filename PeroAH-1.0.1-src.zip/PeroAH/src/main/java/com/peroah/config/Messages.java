package com.peroah.config;

import com.peroah.PeroAH;
import com.peroah.util.Text;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.tag.resolver.TagResolver;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;

public final class Messages {
    private final PeroAH plugin;
    private FileConfiguration yaml;

    public Messages(PeroAH plugin) {
        this.plugin = plugin;
    }

    public void load() {
        File file = new File(plugin.getDataFolder(), "messages.yml");
        if (!file.exists()) {
            plugin.saveResource("messages.yml", false);
        }
        yaml = YamlConfiguration.loadConfiguration(file);
        try (InputStream in = plugin.getResource("messages.yml")) {
            if (in != null) {
                YamlConfiguration def = YamlConfiguration.loadConfiguration(new InputStreamReader(in, StandardCharsets.UTF_8));
                yaml.setDefaults(def);
            }
        } catch (IOException ignored) {
        }
    }

    public String raw(String path) {
        return yaml.getString(path, path);
    }

    public Component prefix() {
        return Text.mm(raw("prefix"));
    }

    public Component get(String path, TagResolver... resolvers) {
        return prefix().append(Text.mm(raw(path), resolvers));
    }

    public Component bare(String path, TagResolver... resolvers) {
        return Text.mm(raw(path), resolvers);
    }

    public void send(CommandSender sender, String path, TagResolver... resolvers) {
        sender.sendMessage(get(path, resolvers));
    }
}
