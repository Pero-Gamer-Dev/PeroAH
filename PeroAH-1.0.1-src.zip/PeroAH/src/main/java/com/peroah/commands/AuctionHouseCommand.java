package com.peroah.commands;

import com.peroah.auction.Auction;
import com.peroah.auction.AuctionManager;
import com.peroah.auction.AuctionType;
import com.peroah.config.ConfigManager;
import com.peroah.config.Messages;
import com.peroah.gui.GuiManager;
import com.peroah.util.Money;
import com.peroah.util.Text;
import com.peroah.util.TimeUtil;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.stream.Stream;

public final class AuctionHouseCommand implements CommandExecutor, TabCompleter {
    private final AuctionManager auctions;
    private final GuiManager guis;
    private final Messages messages;
    private final ConfigManager config;
    private final Runnable reload;

    public AuctionHouseCommand(AuctionManager auctions, GuiManager guis, Messages messages,
                               ConfigManager config, Runnable reload) {
        this.auctions = auctions;
        this.guis = guis;
        this.messages = messages;
        this.config = config;
        this.reload = reload;
    }

    @Override
    public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command,
                             @NotNull String label, @NotNull String[] args) {
        if (!(sender instanceof Player player)) {
            messages.send(sender, "general.players-only");
            return true;
        }
        if (!player.hasPermission("auctionhouse.use")) {
            messages.send(player, "general.no-permission");
            return true;
        }
        if (args.length == 0) {
            guis.openMain(player, 0, "");
            return true;
        }
        switch (args[0].toLowerCase(Locale.ROOT)) {
            case "sell" -> sell(player, args);
            case "bid" -> bid(player, args);
            case "cancel" -> cancel(player, args);
            case "auctions", "mine" -> {
                if (!player.hasPermission("auctionhouse.sell")) {
                    messages.send(player, "general.no-permission");
                    return true;
                }
                guis.openMine(player, 0);
            }
            case "bids", "bidwar", "bidwars" -> guis.openBidWars(player, 0);
            case "claim", "mail" -> {
                if (!player.hasPermission("auctionhouse.claim")) {
                    messages.send(player, "general.no-permission");
                    return true;
                }
                guis.openClaim(player, 0);
            }
            case "search" -> {
                if (!player.hasPermission("auctionhouse.search")) {
                    messages.send(player, "general.no-permission");
                    return true;
                }
                String query = args.length < 2 ? "" : String.join(" ", java.util.Arrays.copyOfRange(args, 1, args.length));
                guis.openMain(player, 0, query);
            }
            case "reload" -> {
                if (!player.hasPermission("auctionhouse.reload")) {
                    messages.send(player, "general.no-permission");
                    return true;
                }
                reload.run();
                messages.send(player, "general.reload");
            }
            case "help" -> messages.send(player, "command.usage");
            default -> {
                Long id = parseId(args[0]);
                if (id != null) {
                    Auction auction = auctions.getLive(id);
                    guis.openView(player, auction);
                } else {
                    messages.send(player, "command.usage");
                }
            }
        }
        return true;
    }

    private void sell(Player player, String[] args) {
        if (!player.hasPermission("auctionhouse.sell")) {
            messages.send(player, "general.no-permission");
            return;
        }
        if (args.length < 2) {
            guis.openSell(player);
            return;
        }
        if (args[1].equalsIgnoreCase("bid") || args[1].equalsIgnoreCase("bidwar")) {
            if (args.length < 3) {
                guis.openSell(player);
                return;
            }
            String raw = String.join(" ", java.util.Arrays.copyOfRange(args, 2, args.length));
            guis.createFromChat(player, AuctionType.BIDWAR, raw);
            return;
        }
        String raw = String.join(" ", java.util.Arrays.copyOfRange(args, 1, args.length));
        guis.createFromChat(player, AuctionType.FIXED_PRICE, raw);
    }

    private void bid(Player player, String[] args) {
        if (!player.hasPermission("auctionhouse.bid")) {
            messages.send(player, "general.no-permission");
            return;
        }
        if (args.length < 3) {
            messages.send(player, "command.usage");
            return;
        }
        Long id = parseId(args[1]);
        Double amount = Money.parse(args[2]);
        if (id == null || amount == null) {
            messages.send(player, "general.invalid-number");
            return;
        }
        Auction auction = auctions.getLive(id);
        AuctionManager.Outcome result = auctions.placeBid(player, id, amount);
        switch (result) {
            case OK -> messages.send(player, "bidwar.placed",
                    Text.ph("price", Money.format(amount, config.currencySymbol())),
                    Text.ph("item", auction == null ? Text.mm("item") : Text.itemName(auction.getItemView())));
            case TOO_LOW -> messages.send(player, "bidwar.too-low",
                    Text.ph("price", Money.format(auction == null ? amount : auction.nextMinimumBid(), config.currencySymbol())));
            case SELF_BID -> messages.send(player, "bidwar.cannot-bid-own");
            case CANNOT_AFFORD -> messages.send(player, "auction.cannot-afford",
                    Text.ph("price", Money.format(amount, config.currencySymbol())));
            default -> messages.send(player, "auction.not-found");
        }
    }

    private void cancel(Player player, String[] args) {
        if (!player.hasPermission("auctionhouse.cancel")) {
            messages.send(player, "general.no-permission");
            return;
        }
        if (args.length < 2) {
            messages.send(player, "command.usage");
            return;
        }
        Long id = parseId(args[1]);
        if (id == null) {
            messages.send(player, "general.invalid-number");
            return;
        }
        AuctionManager.Outcome result = auctions.cancel(player, id, false);
        if (result == AuctionManager.Outcome.OK) {
            messages.send(player, "auction.cancelled", Text.ph("id", String.valueOf(id)));
        } else if (result == AuctionManager.Outcome.HAS_BIDS) {
            player.sendMessage(Text.mm("<red>You cannot cancel a BidWar that already has bids."));
        } else if (result == AuctionManager.Outcome.NOT_OWNER) {
            messages.send(player, "auction.not-yours");
        } else {
            messages.send(player, "auction.not-found");
        }
    }

    private Long parseId(String raw) {
        try {
            String cleaned = raw.startsWith("#") ? raw.substring(1) : raw;
            return Long.parseLong(cleaned);
        } catch (NumberFormatException ex) {
            return null;
        }
    }

    @Override
    public @Nullable List<String> onTabComplete(@NotNull CommandSender sender, @NotNull Command command,
                                                @NotNull String label, @NotNull String[] args) {
        if (args.length == 1) {
            return prefix(args[0], "sell", "bid", "cancel", "auctions", "bids", "claim", "search", "reload", "help");
        }
        if (args.length == 2 && args[0].equalsIgnoreCase("sell")) {
            return prefix(args[1], "bidwar", String.valueOf(1000), "50000");
        }
        if (args.length == 2 && (args[0].equalsIgnoreCase("bid") || args[0].equalsIgnoreCase("cancel"))) {
            return auctions.liveListings().stream().map(a -> String.valueOf(a.getId())).filter(s -> s.startsWith(args[1])).limit(20).toList();
        }
        if (args.length == 3 && args[0].equalsIgnoreCase("sell")) {
            return prefix(args[2], "1h", "6h", "12h", "24h", "30m");
        }
        return List.of();
    }

    private List<String> prefix(String input, String... options) {
        String lower = input.toLowerCase(Locale.ROOT);
        List<String> out = new ArrayList<>();
        Stream.of(options).filter(o -> o.toLowerCase(Locale.ROOT).startsWith(lower)).forEach(out::add);
        return out;
    }
}
