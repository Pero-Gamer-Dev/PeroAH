package com.peroah.commands;

import com.peroah.auction.Auction;
import com.peroah.auction.AuctionManager;
import com.peroah.config.Messages;
import com.peroah.util.Money;
import com.peroah.util.Text;
import com.peroah.util.TimeUtil;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.UUID;

public final class AdminCommand implements CommandExecutor, TabCompleter {
    private final AuctionManager auctions;
    private final Messages messages;
    private final Runnable reload;

    public AdminCommand(AuctionManager auctions, Messages messages, Runnable reload) {
        this.auctions = auctions;
        this.messages = messages;
        this.reload = reload;
    }

    @Override
    public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command,
                             @NotNull String label, @NotNull String[] args) {
        if (!sender.hasPermission("auctionhouse.admin")) {
            messages.send(sender, "general.no-permission");
            return true;
        }
        if (args.length == 0) {
            messages.send(sender, "command.admin-usage");
            return true;
        }
        switch (args[0].toLowerCase(Locale.ROOT)) {
            case "reload" -> {
                reload.run();
                messages.send(sender, "general.reload");
            }
            case "remove" -> {
                if (!sender.hasPermission("auctionhouse.admin.remove") || args.length < 2) {
                    messages.send(sender, "command.admin-usage");
                    return true;
                }
                Long id = parseId(args[1]);
                if (id == null) {
                    messages.send(sender, "general.invalid-number");
                    return true;
                }
                Player actor = sender instanceof Player player ? player : null;
                if (actor == null) {
                    sender.sendMessage(Component.text("Run this in-game so the listing can be cancelled safely.", NamedTextColor.RED));
                    return true;
                }
                AuctionManager.Outcome result = auctions.cancel(actor, id, true);
                if (result == AuctionManager.Outcome.OK) {
                    messages.send(sender, "auction.cancelled", Text.ph("id", String.valueOf(id)));
                } else {
                    messages.send(sender, "auction.not-found");
                }
            }
            case "end" -> {
                if (!sender.hasPermission("auctionhouse.admin.end") || args.length < 2) {
                    messages.send(sender, "command.admin-usage");
                    return true;
                }
                Long id = parseId(args[1]);
                if (id == null) {
                    messages.send(sender, "general.invalid-number");
                    return true;
                }
                AuctionManager.Outcome result = auctions.forceEnd(id);
                if (result == AuctionManager.Outcome.OK) {
                    messages.send(sender, "auction.ended-admin", Text.ph("id", String.valueOf(id)));
                } else {
                    messages.send(sender, "auction.not-found");
                }
            }
            case "inspect" -> {
                if (!sender.hasPermission("auctionhouse.admin.inspect") || args.length < 2) {
                    messages.send(sender, "command.admin-usage");
                    return true;
                }
                Long id = parseId(args[1]);
                Auction auction = id == null ? null : auctions.get(id);
                if (auction == null) {
                    messages.send(sender, "auction.not-found");
                    return true;
                }
                sender.sendMessage(Text.mm("<gold>Listing #" + auction.getId()
                        + " <gray>" + auction.getType() + " / " + auction.getStatus()));
                sender.sendMessage(Text.mm("<gray>Item: <white>" + Text.itemNamePlain(auction.getItemView())
                        + " x" + auction.getAmount()));
                sender.sendMessage(Text.mm("<gray>Price: <white>" + Money.format(auction.getCurrentPrice(), "$")
                        + " <gray>start " + Money.format(auction.getStartingPrice(), "$")));
                sender.sendMessage(Text.mm("<gray>Seller: <white>" + name(auction.getSellerId())));
                sender.sendMessage(Text.mm("<gray>Highest: <white>"
                        + (auction.getHighestBidder() == null ? "-" : name(auction.getHighestBidder()))));
                sender.sendMessage(Text.mm("<gray>Ends: <white>" + TimeUtil.formatRemaining(auction.getExpiresAt())));
            }
            case "clear" -> {
                if (!sender.hasPermission("auctionhouse.admin.clear") || args.length < 2) {
                    messages.send(sender, "command.admin-usage");
                    return true;
                }
                OfflinePlayer target = Bukkit.getOfflinePlayer(args[1]);
                UUID uuid = target.getUniqueId();
                int removed = 0;
                for (Auction auction : List.copyOf(auctions.liveListings())) {
                    if (auction.isSeller(uuid)) {
                        Player actor = sender instanceof Player player ? player : Bukkit.getOnlinePlayers().stream().findFirst().orElse(null);
                        if (actor != null && auctions.cancel(actor, auction.getId(), true) == AuctionManager.Outcome.OK) {
                            removed++;
                        }
                    }
                }
                sender.sendMessage(Text.mm("<yellow>Cleared " + removed + " live listing(s) for " + args[1] + "."));
            }
            default -> messages.send(sender, "command.admin-usage");
        }
        return true;
    }

    private String name(UUID id) {
        String n = Bukkit.getOfflinePlayer(id).getName();
        return n == null ? id.toString() : n;
    }

    private Long parseId(String raw) {
        try {
            return Long.parseLong(raw.startsWith("#") ? raw.substring(1) : raw);
        } catch (NumberFormatException ex) {
            return null;
        }
    }

    @Override
    public @Nullable List<String> onTabComplete(@NotNull CommandSender sender, @NotNull Command command,
                                                @NotNull String label, @NotNull String[] args) {
        if (args.length == 1) {
            return List.of("remove", "inspect", "end", "clear", "reload").stream()
                    .filter(s -> s.startsWith(args[0].toLowerCase(Locale.ROOT))).toList();
        }
        if (args.length == 2 && !args[0].equalsIgnoreCase("reload") && !args[0].equalsIgnoreCase("clear")) {
            List<String> ids = new ArrayList<>();
            auctions.liveListings().forEach(a -> ids.add(String.valueOf(a.getId())));
            return ids;
        }
        return List.of();
    }
}
