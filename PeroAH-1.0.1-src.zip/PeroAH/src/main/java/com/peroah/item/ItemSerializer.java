package com.peroah.item;

import org.bukkit.inventory.ItemStack;

import java.util.Base64;

/**
 * Persists a complete ItemStack including components, PDC, enchantments,
 * attributes, custom model data, potions, trims and lore.
 */
public final class ItemSerializer {
    private ItemSerializer() {}

    public static byte[] serialize(ItemStack stack) {
        if (stack == null || stack.getType().isAir()) {
            return new byte[0];
        }
        return stack.serializeAsBytes();
    }

    public static ItemStack deserialize(byte[] data) {
        if (data == null || data.length == 0) {
            return null;
        }
        return ItemStack.deserializeBytes(data);
    }

    public static String serializeBase64(ItemStack stack) {
        return Base64.getEncoder().encodeToString(serialize(stack));
    }

    public static ItemStack deserializeBase64(String encoded) {
        if (encoded == null || encoded.isBlank()) {
            return null;
        }
        return deserialize(Base64.getDecoder().decode(encoded));
    }
}
