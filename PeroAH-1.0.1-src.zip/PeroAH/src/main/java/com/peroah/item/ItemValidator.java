package com.peroah.item;

import com.peroah.config.ConfigManager;
import org.bukkit.Material;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.Locale;
import java.util.Set;

public final class ItemValidator {
    private final ConfigManager config;

    public ItemValidator(ConfigManager config) {
        this.config = config;
    }

    public boolean canList(ItemStack stack) {
        if (stack == null || stack.getType() == Material.AIR || stack.getAmount() <= 0) {
            return false;
        }
        Set<String> banned = config.blacklistedMaterials();
        if (banned.contains(stack.getType().name().toUpperCase(Locale.ROOT))) {
            return false;
        }
        if (stack.hasItemMeta()) {
            ItemMeta meta = stack.getItemMeta();
            try {
                if (meta.hasCustomModelData()
                        && config.blacklistedCustomModelData().contains(meta.getCustomModelData())) {
                    return false;
                }
            } catch (Throwable ignored) {
                // Custom model data is a data component on some Paper 26.x builds.
            }
        }
        return true;
    }
}
