package com.peroah.item;

import org.bukkit.Material;
import org.bukkit.Tag;
import org.bukkit.inventory.ItemStack;

public enum ItemCategory {
    ALL,
    WEAPONS,
    ARMOR,
    TOOLS,
    BLOCKS,
    MATERIALS,
    FARMING,
    MINING,
    MISCELLANEOUS,
    CUSTOM;

    public boolean matches(ItemStack stack) {
        if (stack == null) {
            return false;
        }
        if (this == ALL) {
            return true;
        }
        if (this == CUSTOM) {
            return stack.hasItemMeta() && (stack.getItemMeta().hasDisplayName()
                    || stack.getItemMeta().hasLore()
                    || stack.getItemMeta().hasEnchants()
                    || stack.getItemMeta().hasCustomModelData());
        }
        Material type = stack.getType();
        return switch (this) {
            case WEAPONS -> Tag.ITEMS_SWORDS.isTagged(type)
                    || Tag.ITEMS_AXES.isTagged(type)
                    || type.name().contains("BOW")
                    || type.name().contains("TRIDENT")
                    || type.name().contains("MACE")
                    || type.name().contains("CROSSBOW");
            case ARMOR -> type.name().endsWith("_HELMET")
                    || type.name().endsWith("_CHESTPLATE")
                    || type.name().endsWith("_LEGGINGS")
                    || type.name().endsWith("_BOOTS")
                    || type == Material.ELYTRA
                    || type == Material.SHIELD;
            case TOOLS -> Tag.ITEMS_PICKAXES.isTagged(type)
                    || Tag.ITEMS_SHOVELS.isTagged(type)
                    || Tag.ITEMS_HOES.isTagged(type)
                    || type == Material.FISHING_ROD
                    || type == Material.FLINT_AND_STEEL
                    || type == Material.SHEARS;
            case BLOCKS -> type.isBlock();
            case MATERIALS -> !type.isBlock() && !type.isEdible();
            case FARMING -> type.isEdible()
                    || Tag.ITEMS_HOES.isTagged(type)
                    || type.name().contains("SEED")
                    || type.name().contains("CROP");
            case MINING -> Tag.ITEMS_PICKAXES.isTagged(type)
                    || type.name().endsWith("_ORE")
                    || type.name().contains("INGOT")
                    || type.name().contains("GEM")
                    || type == Material.DIAMOND
                    || type == Material.EMERALD
                    || type == Material.COAL
                    || type == Material.RAW_IRON
                    || type == Material.RAW_GOLD
                    || type == Material.RAW_COPPER;
            case MISCELLANEOUS -> true;
            default -> true;
        };
    }
}
