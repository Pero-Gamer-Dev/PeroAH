package com.peroah.storage;

import com.peroah.PeroAH;
import com.peroah.config.ConfigManager;
import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;

import java.io.File;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.function.Function;

public final class DatabaseManager {
    private final PeroAH plugin;
    private final ConfigManager config;
    private final ExecutorService executor;
    private HikariDataSource dataSource;
    private boolean mysql;

    public DatabaseManager(PeroAH plugin, ConfigManager config) {
        this.plugin = plugin;
        this.config = config;
        this.executor = Executors.newFixedThreadPool(4, r -> {
            Thread thread = new Thread(r, "PeroAH-DB");
            thread.setDaemon(true);
            return thread;
        });
    }

    public void connect() throws SQLException {
        mysql = "MYSQL".equals(config.databaseType()) || "MARIADB".equals(config.databaseType());
        HikariConfig hikari = new HikariConfig();
        hikari.setPoolName("PeroAH-Pool");
        hikari.setMaximumPoolSize(mysql ? Math.max(2, config.mysqlPoolSize()) : 4);
        hikari.setMinimumIdle(1);
        hikari.setConnectionTimeout(10_000);
        if (mysql) {
            String jdbc = "jdbc:mysql://" + config.mysqlHost() + ":" + config.mysqlPort() + "/"
                    + config.mysqlDatabase()
                    + "?useSSL=false&allowPublicKeyRetrieval=true&characterEncoding=utf8";
            hikari.setJdbcUrl(jdbc);
            hikari.setUsername(config.mysqlUser());
            hikari.setPassword(config.mysqlPassword());
            hikari.setDriverClassName("com.mysql.cj.jdbc.Driver");
        } else {
            File file = new File(plugin.getDataFolder(), "auctionhouse.db");
            hikari.setJdbcUrl("jdbc:sqlite:" + file.getAbsolutePath());
            hikari.setDriverClassName("org.sqlite.JDBC");
            hikari.setMaximumPoolSize(4);
        }
        this.dataSource = new HikariDataSource(hikari);
        migrate();
        plugin.getLogger().info("Database connected (" + (mysql ? "MySQL/MariaDB" : "SQLite") + ").");
    }

    private void migrate() throws SQLException {
        try (Connection connection = dataSource.getConnection(); Statement st = connection.createStatement()) {
            st.executeUpdate("""
                    CREATE TABLE IF NOT EXISTS auction_listings (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        seller_uuid VARCHAR(36) NOT NULL,
                        type VARCHAR(16) NOT NULL,
                        item_data BLOB NOT NULL,
                        amount INTEGER NOT NULL,
                        starting_price DOUBLE NOT NULL,
                        current_price DOUBLE NOT NULL,
                        minimum_increment DOUBLE NOT NULL DEFAULT 0,
                        highest_bidder VARCHAR(36),
                        created_at BIGINT NOT NULL,
                        expires_at BIGINT NOT NULL,
                        status VARCHAR(16) NOT NULL
                    )
                    """.replace("INTEGER PRIMARY KEY AUTOINCREMENT",
                    mysql ? "BIGINT PRIMARY KEY AUTO_INCREMENT" : "INTEGER PRIMARY KEY AUTOINCREMENT"));
            st.executeUpdate("""
                    CREATE TABLE IF NOT EXISTS auction_bids (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        auction_id BIGINT NOT NULL,
                        bidder_uuid VARCHAR(36) NOT NULL,
                        amount DOUBLE NOT NULL,
                        created_at BIGINT NOT NULL
                    )
                    """.replace("INTEGER PRIMARY KEY AUTOINCREMENT",
                    mysql ? "BIGINT PRIMARY KEY AUTO_INCREMENT" : "INTEGER PRIMARY KEY AUTOINCREMENT"));
            st.executeUpdate("""
                    CREATE TABLE IF NOT EXISTS auction_mail (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        player_uuid VARCHAR(36) NOT NULL,
                        mail_type VARCHAR(32) NOT NULL,
                        item_data BLOB,
                        money DOUBLE NOT NULL DEFAULT 0,
                        message VARCHAR(255),
                        claimed INTEGER NOT NULL DEFAULT 0,
                        created_at BIGINT NOT NULL,
                        auction_id BIGINT
                    )
                    """.replace("INTEGER PRIMARY KEY AUTOINCREMENT",
                    mysql ? "BIGINT PRIMARY KEY AUTO_INCREMENT" : "INTEGER PRIMARY KEY AUTOINCREMENT"));
            st.executeUpdate("""
                    CREATE TABLE IF NOT EXISTS auction_reserves (
                        player_uuid VARCHAR(36) NOT NULL,
                        auction_id BIGINT NOT NULL,
                        amount DOUBLE NOT NULL,
                        PRIMARY KEY (player_uuid, auction_id)
                    )
                    """);
            try {
                st.executeUpdate("CREATE INDEX IF NOT EXISTS idx_listings_status ON auction_listings(status)");
                st.executeUpdate("CREATE INDEX IF NOT EXISTS idx_listings_expires ON auction_listings(expires_at)");
                st.executeUpdate("CREATE INDEX IF NOT EXISTS idx_listings_seller ON auction_listings(seller_uuid)");
                st.executeUpdate("CREATE INDEX IF NOT EXISTS idx_bids_auction ON auction_bids(auction_id)");
                st.executeUpdate("CREATE INDEX IF NOT EXISTS idx_mail_player ON auction_mail(player_uuid, claimed)");
            } catch (SQLException ignored) {
                // MySQL older dialects may not support IF NOT EXISTS on indexes
            }
        }
    }

    public Connection connection() throws SQLException {
        return dataSource.getConnection();
    }

    public boolean isMysql() {
        return mysql;
    }

    public <T> CompletableFuture<T> async(Function<Connection, T> work) {
        return CompletableFuture.supplyAsync(() -> {
            try (Connection connection = connection()) {
                return work.apply(connection);
            } catch (SQLException ex) {
                throw new RuntimeException(ex);
            }
        }, executor);
    }

    public void runAsync(Runnable runnable) {
        executor.execute(runnable);
    }

    public ExecutorService executor() {
        return executor;
    }

    public void shutdown() {
        executor.shutdownNow();
        if (dataSource != null) {
            dataSource.close();
        }
    }
}
