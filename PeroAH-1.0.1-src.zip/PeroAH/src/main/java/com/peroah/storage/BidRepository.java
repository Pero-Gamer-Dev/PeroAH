package com.peroah.storage;

import com.peroah.bidding.Bid;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public final class BidRepository {
    private final DatabaseManager database;

    public BidRepository(DatabaseManager database) {
        this.database = database;
    }

    public void insert(Bid bid) throws SQLException {
        String sql = "INSERT INTO auction_bids (auction_id, bidder_uuid, amount, created_at) VALUES (?, ?, ?, ?)";
        try (Connection connection = database.connection(); PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setLong(1, bid.getAuctionId());
            ps.setString(2, bid.getBidderId().toString());
            ps.setDouble(3, bid.getAmount());
            ps.setLong(4, bid.getCreatedAt());
            ps.executeUpdate();
        }
    }

    public List<Bid> findByAuction(long auctionId) throws SQLException {
        String sql = "SELECT * FROM auction_bids WHERE auction_id = ? ORDER BY created_at DESC";
        List<Bid> list = new ArrayList<>();
        try (Connection connection = database.connection(); PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setLong(1, auctionId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Bid bid = new Bid();
                    bid.setId(rs.getLong("id"));
                    bid.setAuctionId(rs.getLong("auction_id"));
                    bid.setBidderId(UUID.fromString(rs.getString("bidder_uuid")));
                    bid.setAmount(rs.getDouble("amount"));
                    bid.setCreatedAt(rs.getLong("created_at"));
                    list.add(bid);
                }
            }
        }
        return list;
    }
}
