package com.peroah.storage;

import com.peroah.item.ItemSerializer;
import com.peroah.mail.MailItem;
import com.peroah.mail.MailType;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public final class MailRepository {
    private final DatabaseManager database;

    public MailRepository(DatabaseManager database) {
        this.database = database;
    }

    public MailItem insert(MailItem mail) throws SQLException {
        String sql = """
                INSERT INTO auction_mail
                (player_uuid, mail_type, item_data, money, message, claimed, created_at, auction_id)
                VALUES (?, ?, ?, ?, ?, 0, ?, ?)
                """;
        try (Connection connection = database.connection();
             PreparedStatement ps = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, mail.getPlayerId().toString());
            ps.setString(2, mail.getType().name());
            ps.setBytes(3, mail.getItem() == null ? null : ItemSerializer.serialize(mail.getItem()));
            ps.setDouble(4, mail.getMoney());
            ps.setString(5, mail.getMessage());
            ps.setLong(6, mail.getCreatedAt());
            if (mail.getAuctionId() == null) {
                ps.setObject(7, null);
            } else {
                ps.setLong(7, mail.getAuctionId());
            }
            ps.executeUpdate();
            try (ResultSet keys = ps.getGeneratedKeys()) {
                if (keys.next()) {
                    mail.setId(keys.getLong(1));
                }
            }
            return mail;
        }
    }

    public List<MailItem> findUnclaimed(UUID player) throws SQLException {
        String sql = "SELECT * FROM auction_mail WHERE player_uuid = ? AND claimed = 0 ORDER BY created_at DESC";
        List<MailItem> list = new ArrayList<>();
        try (Connection connection = database.connection(); PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setString(1, player.toString());
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    list.add(map(rs));
                }
            }
        }
        return list;
    }

    public int countUnclaimed(UUID player) throws SQLException {
        String sql = "SELECT COUNT(*) FROM auction_mail WHERE player_uuid = ? AND claimed = 0";
        try (Connection connection = database.connection(); PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setString(1, player.toString());
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? rs.getInt(1) : 0;
            }
        }
    }

    public MailItem findById(long id) throws SQLException {
        try (Connection connection = database.connection();
             PreparedStatement ps = connection.prepareStatement("SELECT * FROM auction_mail WHERE id = ?")) {
            ps.setLong(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? map(rs) : null;
            }
        }
    }

    public boolean markClaimed(long id) throws SQLException {
        try (Connection connection = database.connection();
             PreparedStatement ps = connection.prepareStatement(
                     "UPDATE auction_mail SET claimed = 1 WHERE id = ? AND claimed = 0")) {
            ps.setLong(1, id);
            return ps.executeUpdate() > 0;
        }
    }

    private MailItem map(ResultSet rs) throws SQLException {
        MailItem mail = new MailItem();
        mail.setId(rs.getLong("id"));
        mail.setPlayerId(UUID.fromString(rs.getString("player_uuid")));
        mail.setType(MailType.valueOf(rs.getString("mail_type")));
        byte[] data = rs.getBytes("item_data");
        mail.setItem(data == null ? null : ItemSerializer.deserialize(data));
        mail.setMoney(rs.getDouble("money"));
        mail.setMessage(rs.getString("message"));
        mail.setClaimed(rs.getInt("claimed") == 1);
        mail.setCreatedAt(rs.getLong("created_at"));
        long auctionId = rs.getLong("auction_id");
        mail.setAuctionId(rs.wasNull() ? null : auctionId);
        return mail;
    }
}
