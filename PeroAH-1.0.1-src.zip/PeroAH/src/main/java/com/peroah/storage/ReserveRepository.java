package com.peroah.storage;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.UUID;

public final class ReserveRepository {
    private final DatabaseManager database;

    public ReserveRepository(DatabaseManager database) {
        this.database = database;
    }

    public void set(UUID player, long auctionId, double amount) throws SQLException {
        String sql = database.isMysql()
                ? "INSERT INTO auction_reserves (player_uuid, auction_id, amount) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE amount = VALUES(amount)"
                : "INSERT INTO auction_reserves (player_uuid, auction_id, amount) VALUES (?, ?, ?) ON CONFLICT(player_uuid, auction_id) DO UPDATE SET amount = excluded.amount";
        try (Connection connection = database.connection(); PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setString(1, player.toString());
            ps.setLong(2, auctionId);
            ps.setDouble(3, amount);
            ps.executeUpdate();
        }
    }

    public void clear(UUID player, long auctionId) throws SQLException {
        try (Connection connection = database.connection();
             PreparedStatement ps = connection.prepareStatement(
                     "DELETE FROM auction_reserves WHERE player_uuid = ? AND auction_id = ?")) {
            ps.setString(1, player.toString());
            ps.setLong(2, auctionId);
            ps.executeUpdate();
        }
    }

    public void clearAuction(long auctionId) throws SQLException {
        try (Connection connection = database.connection();
             PreparedStatement ps = connection.prepareStatement("DELETE FROM auction_reserves WHERE auction_id = ?")) {
            ps.setLong(1, auctionId);
            ps.executeUpdate();
        }
    }

    public double totalFor(UUID player) throws SQLException {
        try (Connection connection = database.connection();
             PreparedStatement ps = connection.prepareStatement(
                     "SELECT COALESCE(SUM(amount), 0) FROM auction_reserves WHERE player_uuid = ?")) {
            ps.setString(1, player.toString());
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? rs.getDouble(1) : 0;
            }
        }
    }

    public double forAuction(UUID player, long auctionId) throws SQLException {
        try (Connection connection = database.connection();
             PreparedStatement ps = connection.prepareStatement(
                     "SELECT amount FROM auction_reserves WHERE player_uuid = ? AND auction_id = ?")) {
            ps.setString(1, player.toString());
            ps.setLong(2, auctionId);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? rs.getDouble(1) : 0;
            }
        }
    }
}
