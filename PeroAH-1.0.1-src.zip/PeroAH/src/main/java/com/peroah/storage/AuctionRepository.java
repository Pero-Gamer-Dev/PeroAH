package com.peroah.storage;

import com.peroah.auction.Auction;
import com.peroah.auction.AuctionStatus;
import com.peroah.auction.AuctionType;
import com.peroah.item.ItemSerializer;
import org.bukkit.inventory.ItemStack;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public final class AuctionRepository {
    private final DatabaseManager database;

    public AuctionRepository(DatabaseManager database) {
        this.database = database;
    }

    public Auction insert(Auction auction) throws SQLException {
        String sql = """
                INSERT INTO auction_listings
                (seller_uuid, type, item_data, amount, starting_price, current_price, minimum_increment,
                 highest_bidder, created_at, expires_at, status)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """;
        try (Connection connection = database.connection();
             PreparedStatement ps = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            bind(ps, auction);
            ps.executeUpdate();
            try (ResultSet keys = ps.getGeneratedKeys()) {
                if (keys.next()) {
                    auction.setId(keys.getLong(1));
                }
            }
            return auction;
        }
    }

    public void update(Auction auction) throws SQLException {
        String sql = """
                UPDATE auction_listings SET
                    current_price = ?, minimum_increment = ?, highest_bidder = ?, expires_at = ?, status = ?
                WHERE id = ?
                """;
        try (Connection connection = database.connection(); PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setDouble(1, auction.getCurrentPrice());
            ps.setDouble(2, auction.getMinimumIncrement());
            if (auction.getHighestBidder() == null) {
                ps.setString(3, null);
            } else {
                ps.setString(3, auction.getHighestBidder().toString());
            }
            ps.setLong(4, auction.getExpiresAt());
            ps.setString(5, auction.getStatus().name());
            ps.setLong(6, auction.getId());
            ps.executeUpdate();
        }
    }

    public Auction findById(long id) throws SQLException {
        try (Connection connection = database.connection();
             PreparedStatement ps = connection.prepareStatement("SELECT * FROM auction_listings WHERE id = ?")) {
            ps.setLong(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return map(rs);
                }
            }
        }
        return null;
    }

    public List<Auction> findLive() throws SQLException {
        return query("SELECT * FROM auction_listings WHERE status IN ('ACTIVE','BIDDING','ENDING') ORDER BY created_at DESC");
    }

    public List<Auction> findExpiring(long now) throws SQLException {
        String sql = "SELECT * FROM auction_listings WHERE status IN ('ACTIVE','BIDDING','ENDING') AND expires_at <= ?";
        List<Auction> list = new ArrayList<>();
        try (Connection connection = database.connection(); PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setLong(1, now);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    list.add(map(rs));
                }
            }
        }
        return list;
    }

    public List<Auction> findBySeller(UUID seller) throws SQLException {
        String sql = "SELECT * FROM auction_listings WHERE seller_uuid = ? ORDER BY created_at DESC";
        List<Auction> list = new ArrayList<>();
        try (Connection connection = database.connection(); PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setString(1, seller.toString());
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    list.add(map(rs));
                }
            }
        }
        return list;
    }

    public int countLiveBySeller(UUID seller) throws SQLException {
        String sql = "SELECT COUNT(*) FROM auction_listings WHERE seller_uuid = ? AND status IN ('ACTIVE','BIDDING','ENDING')";
        try (Connection connection = database.connection(); PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setString(1, seller.toString());
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? rs.getInt(1) : 0;
            }
        }
    }

    private List<Auction> query(String sql) throws SQLException {
        List<Auction> list = new ArrayList<>();
        try (Connection connection = database.connection();
             PreparedStatement ps = connection.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                list.add(map(rs));
            }
        }
        return list;
    }

    private void bind(PreparedStatement ps, Auction auction) throws SQLException {
        ps.setString(1, auction.getSellerId().toString());
        ps.setString(2, auction.getType().name());
        ps.setBytes(3, ItemSerializer.serialize(auction.getItemView()));
        ps.setInt(4, auction.getAmount());
        ps.setDouble(5, auction.getStartingPrice());
        ps.setDouble(6, auction.getCurrentPrice());
        ps.setDouble(7, auction.getMinimumIncrement());
        ps.setString(8, auction.getHighestBidder() == null ? null : auction.getHighestBidder().toString());
        ps.setLong(9, auction.getCreatedAt());
        ps.setLong(10, auction.getExpiresAt());
        ps.setString(11, auction.getStatus().name());
    }

    private Auction map(ResultSet rs) throws SQLException {
        Auction auction = new Auction();
        auction.setId(rs.getLong("id"));
        auction.setSellerId(UUID.fromString(rs.getString("seller_uuid")));
        auction.setType(AuctionType.from(rs.getString("type")));
        ItemStack item = ItemSerializer.deserialize(rs.getBytes("item_data"));
        auction.setItem(item);
        auction.setAmount(rs.getInt("amount"));
        auction.setStartingPrice(rs.getDouble("starting_price"));
        auction.setCurrentPrice(rs.getDouble("current_price"));
        auction.setMinimumIncrement(rs.getDouble("minimum_increment"));
        String bidder = rs.getString("highest_bidder");
        auction.setHighestBidder(bidder == null || bidder.isBlank() ? null : UUID.fromString(bidder));
        auction.setCreatedAt(rs.getLong("created_at"));
        auction.setExpiresAt(rs.getLong("expires_at"));
        auction.setStatus(AuctionStatus.from(rs.getString("status")));
        return auction;
    }
}
