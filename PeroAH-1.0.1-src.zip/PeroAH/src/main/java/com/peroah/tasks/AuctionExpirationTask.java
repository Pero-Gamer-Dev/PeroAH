package com.peroah.tasks;

import com.peroah.auction.AuctionManager;
import org.bukkit.scheduler.BukkitRunnable;

public final class AuctionExpirationTask extends BukkitRunnable {
    private final AuctionManager auctions;

    public AuctionExpirationTask(AuctionManager auctions) {
        this.auctions = auctions;
    }

    @Override
    public void run() {
        auctions.processExpirations();
    }
}
