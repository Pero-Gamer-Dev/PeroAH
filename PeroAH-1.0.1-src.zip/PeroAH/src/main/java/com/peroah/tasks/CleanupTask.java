package com.peroah.tasks;

import com.peroah.storage.DatabaseManager;
import org.bukkit.scheduler.BukkitRunnable;

import java.sql.SQLException;
import java.util.logging.Logger;

/**
 * Periodic maintenance: claimed mail older than 30 days is purged.
 */
public final class CleanupTask extends BukkitRunnable {
    private final DatabaseManager database;
    private final Logger logger;

    public CleanupTask(DatabaseManager database, Logger logger) {
        this.database = database;
        this.logger = logger;
    }

    @Override
    public void run() {
        long cutoff = System.currentTimeMillis() - 30L * 24 * 60 * 60 * 1000;
        database.runAsync(() -> {
            try (var connection = database.connection();
                 var ps = connection.prepareStatement(
                         "DELETE FROM auction_mail WHERE claimed = 1 AND created_at < ?")) {
                ps.setLong(1, cutoff);
                int removed = ps.executeUpdate();
                if (removed > 0) {
                    logger.info("Purged " + removed + " claimed mail row(s).");
                }
            } catch (SQLException ex) {
                logger.warning("Mail cleanup failed: " + ex.getMessage());
            }
        });
    }
}
