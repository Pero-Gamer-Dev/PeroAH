package com.peroah.auction;

import org.bukkit.inventory.ItemStack;

import java.util.UUID;

public final class Auction {
    private long id;
    private UUID sellerId;
    private AuctionType type;
    private ItemStack item;
    private int amount;
    private double startingPrice;
    private double currentPrice;
    private double minimumIncrement;
    private UUID highestBidder;
    private long createdAt;
    private long expiresAt;
    private AuctionStatus status;

    public Auction() {}

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public UUID getSellerId() {
        return sellerId;
    }

    public void setSellerId(UUID sellerId) {
        this.sellerId = sellerId;
    }

    public AuctionType getType() {
        return type;
    }

    public void setType(AuctionType type) {
        this.type = type;
    }

    public ItemStack getItem() {
        return item == null ? null : item.clone();
    }

    public ItemStack getItemView() {
        return item;
    }

    public void setItem(ItemStack item) {
        this.item = item == null ? null : item.clone();
    }

    public int getAmount() {
        return amount;
    }

    public void setAmount(int amount) {
        this.amount = amount;
    }

    public double getStartingPrice() {
        return startingPrice;
    }

    public void setStartingPrice(double startingPrice) {
        this.startingPrice = startingPrice;
    }

    public double getCurrentPrice() {
        return currentPrice;
    }

    public void setCurrentPrice(double currentPrice) {
        this.currentPrice = currentPrice;
    }

    public double getMinimumIncrement() {
        return minimumIncrement;
    }

    public void setMinimumIncrement(double minimumIncrement) {
        this.minimumIncrement = minimumIncrement;
    }

    public UUID getHighestBidder() {
        return highestBidder;
    }

    public void setHighestBidder(UUID highestBidder) {
        this.highestBidder = highestBidder;
    }

    public long getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(long createdAt) {
        this.createdAt = createdAt;
    }

    public long getExpiresAt() {
        return expiresAt;
    }

    public void setExpiresAt(long expiresAt) {
        this.expiresAt = expiresAt;
    }

    public AuctionStatus getStatus() {
        return status;
    }

    public void setStatus(AuctionStatus status) {
        this.status = status;
    }

    public boolean isBidWar() {
        return type == AuctionType.BIDWAR;
    }

    public boolean isExpired(long now) {
        return expiresAt > 0 && now >= expiresAt;
    }

    public double nextMinimumBid() {
        if (highestBidder == null) {
            return startingPrice;
        }
        return currentPrice + minimumIncrement;
    }

    public boolean isSeller(UUID player) {
        return sellerId != null && sellerId.equals(player);
    }
}
