package com.peroah.auction;

import com.peroah.PeroAH;
import com.peroah.api.event.AuctionCancelEvent;
import com.peroah.api.event.AuctionCreateEvent;
import com.peroah.api.event.AuctionExpireEvent;
import com.peroah.api.event.AuctionPurchaseEvent;
import com.peroah.api.event.BidPlaceEvent;
import com.peroah.api.event.BidWarEndEvent;
import com.peroah.bidding.Bid;
import com.peroah.bidding.BidValidator;
import com.peroah.config.ConfigManager;
import com.peroah.economy.EconomyService;
import com.peroah.item.ItemValidator;
import com.peroah.mail.MailManager;
import com.peroah.mail.MailType;
import com.peroah.notification.NotificationManager;
import com.peroah.storage.AuctionRepository;
import com.peroah.storage.BidRepository;
import com.peroah.storage.ReserveRepository;
import com.peroah.util.Money;
import com.peroah.util.Text;
import com.peroah.util.TimeUtil;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Level;
import java.util.stream.Collectors;

public final class AuctionManager {
    public enum Outcome {
        OK,
        NO_ECONOMY,
        INVALID_ITEM,
        BLACKLISTED,
        MAX_LISTINGS,
        CANNOT_AFFORD_FEE,
        EVENT_CANCELLED,
        NOT_FOUND,
        NOT_ACTIVE,
        EXPIRED,
        OWN_LISTING,
        CANNOT_AFFORD,
        NOT_OWNER,
        HAS_BIDS,
        TOO_LOW,
        SELF_BID,
        BIDWAR_DISABLED,
        FAILED
    }

    private final PeroAH plugin;
    private final ConfigManager config;
    private final EconomyService economy;
    private final AuctionRepository auctions;
    private final BidRepository bids;
    private final ReserveRepository reserves;
    private final MailManager mail;
    private final NotificationManager notify;
    private final ItemValidator validator;
    private final BidValidator bidValidator = new BidValidator();

    private final Map<Long, Auction> live = new ConcurrentHashMap<>();
    private final Map<Long, Object> locks = new ConcurrentHashMap<>();

    public AuctionManager(PeroAH plugin,
                          ConfigManager config,
                          EconomyService economy,
                          AuctionRepository auctions,
                          BidRepository bids,
                          ReserveRepository reserves,
                          MailManager mail,
                          NotificationManager notify,
                          ItemValidator validator) {
        this.plugin = plugin;
        this.config = config;
        this.economy = economy;
        this.auctions = auctions;
        this.bids = bids;
        this.reserves = reserves;
        this.mail = mail;
        this.notify = notify;
        this.validator = validator;
    }

    public void loadCache() {
        try {
            live.clear();
            for (Auction auction : auctions.findLive()) {
                live.put(auction.getId(), auction);
            }
            plugin.getLogger().info("Loaded " + live.size() + " live listings.");
        } catch (SQLException ex) {
            plugin.getLogger().log(Level.SEVERE, "Failed to load listings", ex);
        }
    }

    public List<Auction> liveListings() {
        return new ArrayList<>(live.values());
    }

    public List<Auction> liveOfType(AuctionType type) {
        return live.values().stream().filter(a -> a.getType() == type).collect(Collectors.toList());
    }

    public Auction getLive(long id) {
        return live.get(id);
    }

    public Auction get(long id) {
        Auction cached = live.get(id);
        if (cached != null) {
            return cached;
        }
        try {
            return auctions.findById(id);
        } catch (SQLException ex) {
            plugin.getLogger().log(Level.WARNING, "Lookup failed for #" + id, ex);
            return null;
        }
    }

    private Object lockFor(long id) {
        return locks.computeIfAbsent(id, key -> new Object());
    }

    public Outcome createListing(Player seller, ItemStack item, AuctionType type, double price, double increment, long durationSeconds) {
        if (!economy.available()) {
            return Outcome.NO_ECONOMY;
        }
        if (item == null || item.getType().isAir()) {
            return Outcome.INVALID_ITEM;
        }
        if (!validator.canList(item)) {
            return Outcome.BLACKLISTED;
        }
        if (type == AuctionType.BIDWAR && !config.bidWarEnabled()) {
            return Outcome.BIDWAR_DISABLED;
        }
        if (!seller.hasPermission("auctionhouse.bypass.limit")) {
            int current = (int) live.values().stream().filter(a -> a.isSeller(seller.getUniqueId())).count();
            if (current >= config.maxListings()) {
                return Outcome.MAX_LISTINGS;
            }
        }
        double listingFee = config.feesEnabled() ? config.listingFee() : 0;
        if (listingFee > 0 && !economy.has(seller.getUniqueId(), listingFee)) {
            return Outcome.CANNOT_AFFORD_FEE;
        }

        long min = type == AuctionType.BIDWAR ? config.bidWarMinDuration() : config.minDurationSeconds();
        long max = type == AuctionType.BIDWAR ? config.bidWarMaxDuration() : config.maxDurationSeconds();
        long duration = Math.max(min, Math.min(max, durationSeconds));

        ItemStack listed = item.clone();
        Auction auction = new Auction();
        auction.setSellerId(seller.getUniqueId());
        auction.setType(type);
        auction.setItem(listed);
        auction.setAmount(listed.getAmount());
        auction.setStartingPrice(Money.normalize(price));
        auction.setCurrentPrice(Money.normalize(price));
        auction.setMinimumIncrement(type == AuctionType.BIDWAR
                ? Math.max(config.bidWarMinIncrement(), Money.normalize(increment))
                : 0);
        auction.setCreatedAt(TimeUtil.now());
        auction.setExpiresAt(TimeUtil.now() + duration * 1000L);
        auction.setStatus(type == AuctionType.BIDWAR ? AuctionStatus.BIDDING : AuctionStatus.ACTIVE);

        AuctionCreateEvent event = new AuctionCreateEvent(auction);
        Bukkit.getPluginManager().callEvent(event);
        if (event.isCancelled()) {
            return Outcome.EVENT_CANCELLED;
        }

        if (!removeExact(seller, listed)) {
            return Outcome.INVALID_ITEM;
        }
        if (listingFee > 0 && !economy.withdraw(seller.getUniqueId(), listingFee)) {
            seller.getInventory().addItem(listed);
            return Outcome.CANNOT_AFFORD_FEE;
        }

        try {
            auctions.insert(auction);
            live.put(auction.getId(), auction);
            return Outcome.OK;
        } catch (SQLException ex) {
            plugin.getLogger().log(Level.SEVERE, "Failed to persist listing", ex);
            seller.getInventory().addItem(listed);
            if (listingFee > 0) {
                economy.deposit(seller.getUniqueId(), listingFee);
            }
            return Outcome.FAILED;
        }
    }

    public Outcome buy(Player buyer, long auctionId) {
        if (!economy.available()) {
            return Outcome.NO_ECONOMY;
        }
        synchronized (lockFor(auctionId)) {
            Auction auction = live.get(auctionId);
            if (auction == null) {
                return Outcome.NOT_FOUND;
            }
            if (auction.isBidWar()) {
                return Outcome.NOT_ACTIVE;
            }
            if (!auction.getStatus().isLive()) {
                return Outcome.NOT_ACTIVE;
            }
            if (auction.isExpired(TimeUtil.now())) {
                expireLocked(auction);
                return Outcome.EXPIRED;
            }
            if (auction.isSeller(buyer.getUniqueId()) && !config.allowSelfPurchase()) {
                return Outcome.OWN_LISTING;
            }
            double price = auction.getCurrentPrice();
            if (!economy.has(buyer.getUniqueId(), price)) {
                return Outcome.CANNOT_AFFORD;
            }
            if (!economy.withdraw(buyer.getUniqueId(), price)) {
                return Outcome.CANNOT_AFFORD;
            }

            auction.setStatus(AuctionStatus.SOLD);
            live.remove(auctionId);
            persistQuiet(auction);

            paySeller(auction, price);
            deliverItem(buyer.getUniqueId(), auction.getItem(), MailType.PURCHASED_ITEM, auction.getId());
            notify.sold(auction.getSellerId(), auction.getItemView(), price);
            Bukkit.getPluginManager().callEvent(new AuctionPurchaseEvent(auction, buyer.getUniqueId()));
            return Outcome.OK;
        }
    }

    public Outcome placeBid(Player bidder, long auctionId, double amount) {
        if (!economy.available()) {
            return Outcome.NO_ECONOMY;
        }
        if (!config.bidWarEnabled()) {
            return Outcome.BIDWAR_DISABLED;
        }
        double bidAmount = Money.normalize(amount);
        synchronized (lockFor(auctionId)) {
            Auction auction = live.get(auctionId);
            double reservedOther;
            try {
                reservedOther = reserves.totalFor(bidder.getUniqueId()) - reserves.forAuction(bidder.getUniqueId(), auctionId);
            } catch (SQLException ex) {
                plugin.getLogger().log(Level.WARNING, "Reserve lookup failed", ex);
                return Outcome.FAILED;
            }
            double alreadyOnThis = 0;
            try {
                alreadyOnThis = reserves.forAuction(bidder.getUniqueId(), auctionId);
            } catch (SQLException ignored) {
            }
            double extraNeeded = Math.max(0, bidAmount - alreadyOnThis);
            boolean canAfford = economy.hasAvailable(bidder.getUniqueId(), extraNeeded, reservedOther);
            BidValidator.Result check = bidValidator.validate(auction, bidder.getUniqueId(), bidAmount, canAfford);
            return switch (check) {
                case MISSING -> Outcome.NOT_FOUND;
                case NOT_BIDWAR, NOT_ACTIVE -> Outcome.NOT_ACTIVE;
                case EXPIRED -> {
                    expireLocked(auction);
                    yield Outcome.EXPIRED;
                }
                case SELF_BID -> Outcome.SELF_BID;
                case TOO_LOW -> Outcome.TOO_LOW;
                case INSUFFICIENT_FUNDS -> Outcome.CANNOT_AFFORD;
                case OK -> applyBid(auction, bidder.getUniqueId(), bidAmount);
            };
        }
    }

    private Outcome applyBid(Auction auction, UUID bidder, double amount) {
        BidPlaceEvent event = new BidPlaceEvent(auction, bidder, amount);
        Bukkit.getPluginManager().callEvent(event);
        if (event.isCancelled()) {
            return Outcome.EVENT_CANCELLED;
        }

        UUID previous = auction.getHighestBidder();
        double previousAmount = auction.getCurrentPrice();

        try {
            double already = reserves.forAuction(bidder, auction.getId());
            double extra = Math.max(0, amount - already);
            if (extra > 0 && !economy.withdraw(bidder, extra)) {
                return Outcome.CANNOT_AFFORD;
            }
            if (previous != null && !previous.equals(bidder)) {
                reserves.clear(previous, auction.getId());
                mail.sendMoney(previous, MailType.OUTBID_REFUND, previousAmount,
                        "Outbid refund", auction.getId());
                notify.outbid(previous, auction.getItemView(), previousAmount, amount);
            }
            reserves.set(bidder, auction.getId(), amount);
            auction.setHighestBidder(bidder);
            auction.setCurrentPrice(amount);

            if (config.antiSnipeEnabled()) {
                long remaining = auction.getExpiresAt() - TimeUtil.now();
                if (remaining <= config.antiSnipeTriggerMillis()) {
                    auction.setExpiresAt(auction.getExpiresAt() + config.antiSnipeExtensionMillis());
                }
            }

            persistQuiet(auction);
            bids.insert(new Bid(auction.getId(), bidder, amount, TimeUtil.now()));
            return Outcome.OK;
        } catch (SQLException ex) {
            plugin.getLogger().log(Level.SEVERE, "Failed to place bid", ex);
            return Outcome.FAILED;
        }
    }

    public Outcome cancel(Player actor, long auctionId, boolean admin) {
        synchronized (lockFor(auctionId)) {
            Auction auction = live.get(auctionId);
            if (auction == null) {
                return Outcome.NOT_FOUND;
            }
            if (!admin && !auction.isSeller(actor.getUniqueId())) {
                return Outcome.NOT_OWNER;
            }
            if (auction.isBidWar() && auction.getHighestBidder() != null && !admin) {
                return Outcome.HAS_BIDS;
            }
            if (auction.isBidWar() && auction.getHighestBidder() != null) {
                refundHighest(auction);
            }
            auction.setStatus(AuctionStatus.CANCELLED);
            live.remove(auctionId);
            persistQuiet(auction);
            deliverItem(auction.getSellerId(), auction.getItem(), MailType.CANCELLED_ITEM, auction.getId());
            Bukkit.getPluginManager().callEvent(new AuctionCancelEvent(auction));
            return Outcome.OK;
        }
    }

    public Outcome forceEnd(long auctionId) {
        synchronized (lockFor(auctionId)) {
            Auction auction = live.get(auctionId);
            if (auction == null) {
                return Outcome.NOT_FOUND;
            }
            if (auction.isBidWar()) {
                completeBidWarLocked(auction);
            } else {
                expireLocked(auction);
            }
            return Outcome.OK;
        }
    }

    public void processExpirations() {
        long now = TimeUtil.now();
        List<Auction> due = live.values().stream()
                .filter(a -> a.isExpired(now))
                .toList();
        for (Auction auction : due) {
            synchronized (lockFor(auction.getId())) {
                Auction current = live.get(auction.getId());
                if (current == null || !current.isExpired(TimeUtil.now())) {
                    continue;
                }
                if (current.isBidWar()) {
                    completeBidWarLocked(current);
                } else {
                    expireLocked(current);
                }
            }
        }
    }

    private void expireLocked(Auction auction) {
        auction.setStatus(AuctionStatus.EXPIRED);
        live.remove(auction.getId());
        persistQuiet(auction);
        deliverItem(auction.getSellerId(), auction.getItem(), MailType.EXPIRED_AUCTION, auction.getId());
        notify.expired(auction.getSellerId(), auction.getItemView());
        Bukkit.getPluginManager().callEvent(new AuctionExpireEvent(auction));
    }

    private void completeBidWarLocked(Auction auction) {
        UUID winner = auction.getHighestBidder();
        if (winner == null) {
            auction.setStatus(AuctionStatus.EXPIRED);
            live.remove(auction.getId());
            persistQuiet(auction);
            clearReserves(auction.getId());
            deliverItem(auction.getSellerId(), auction.getItem(), MailType.EXPIRED_AUCTION, auction.getId());
            notify.expired(auction.getSellerId(), auction.getItemView());
            Bukkit.getPluginManager().callEvent(new BidWarEndEvent(auction, null));
            return;
        }

        double price = auction.getCurrentPrice();
        try {
            // Winning bid was already withdrawn into escrow when placed.
            reserves.clearAuction(auction.getId());
        } catch (SQLException ex) {
            plugin.getLogger().log(Level.SEVERE, "Failed to settle BidWar #" + auction.getId(), ex);
            return;
        }

        auction.setStatus(AuctionStatus.COMPLETED);
        live.remove(auction.getId());
        persistQuiet(auction);
        paySeller(auction, price);
        deliverItem(winner, auction.getItem(), MailType.BIDWAR_WON, auction.getId());
        notify.won(winner, auction.getItemView(), price);
        notify.sold(auction.getSellerId(), auction.getItemView(), price);
        Bukkit.getPluginManager().callEvent(new BidWarEndEvent(auction, winner));
    }

    private void refundHighest(Auction auction) {
        UUID bidder = auction.getHighestBidder();
        if (bidder == null) {
            return;
        }
        try {
            reserves.clear(bidder, auction.getId());
            mail.sendMoney(bidder, MailType.OUTBID_REFUND, auction.getCurrentPrice(), "Bid refund", auction.getId());
        } catch (SQLException ex) {
            plugin.getLogger().log(Level.SEVERE, "Failed to refund bidder", ex);
        }
    }

    private void paySeller(Auction auction, double price) {
        double tax = 0;
        Player sellerOnline = Bukkit.getPlayer(auction.getSellerId());
        boolean bypass = sellerOnline != null && sellerOnline.hasPermission("auctionhouse.bypass.tax");
        if (config.feesEnabled() && !bypass) {
            tax = Money.normalize(price * (config.saleTaxPercent() / 100.0));
        }
        double payout = Money.normalize(price - tax);
        try {
            mail.sendMoney(auction.getSellerId(), MailType.AUCTION_EARNINGS, payout,
                    "Sale of " + Text.itemNamePlain(auction.getItemView()), auction.getId());
        } catch (SQLException ex) {
            plugin.getLogger().log(Level.SEVERE, "Failed to mail earnings, depositing directly", ex);
            economy.deposit(auction.getSellerId(), payout);
        }
    }

    private void deliverItem(UUID player, ItemStack item, MailType type, long auctionId) {
        try {
            mail.sendItem(player, type, item, type.name(), auctionId);
        } catch (SQLException ex) {
            plugin.getLogger().log(Level.SEVERE, "Failed to mail item, attempting direct give", ex);
            Player online = Bukkit.getPlayer(player);
            if (online != null) {
                Map<Integer, ItemStack> leftover = online.getInventory().addItem(item);
                leftover.values().forEach(stack -> online.getWorld().dropItemNaturally(online.getLocation(), stack));
            }
        }
    }

    private void persistQuiet(Auction auction) {
        try {
            auctions.update(auction);
        } catch (SQLException ex) {
            plugin.getLogger().log(Level.SEVERE, "Failed to persist auction #" + auction.getId(), ex);
        }
    }

    private void clearReserves(long auctionId) {
        try {
            reserves.clearAuction(auctionId);
        } catch (SQLException ex) {
            plugin.getLogger().log(Level.WARNING, "Failed to clear reserves", ex);
        }
    }

    private boolean removeExact(Player player, ItemStack target) {
        ItemStack[] contents = player.getInventory().getStorageContents();
        for (int i = 0; i < contents.length; i++) {
            ItemStack slot = contents[i];
            if (slot != null && slot.isSimilar(target) && slot.getAmount() >= target.getAmount()) {
                slot.setAmount(slot.getAmount() - target.getAmount());
                if (slot.getAmount() <= 0) {
                    contents[i] = null;
                }
                player.getInventory().setStorageContents(contents);
                return true;
            }
        }
        if (player.getInventory().getItemInMainHand().isSimilar(target)
                && player.getInventory().getItemInMainHand().getAmount() >= target.getAmount()) {
            ItemStack hand = player.getInventory().getItemInMainHand();
            hand.setAmount(hand.getAmount() - target.getAmount());
            return true;
        }
        return false;
    }

    public List<Auction> search(String query, AuctionType typeFilter, Sort sort) {
        String q = query == null ? "" : query.toLowerCase(Locale.ROOT);
        return live.values().stream()
                .filter(a -> typeFilter == null || a.getType() == typeFilter)
                .filter(a -> q.isEmpty() || Text.itemNamePlain(a.getItemView()).toLowerCase(Locale.ROOT).contains(q)
                        || a.getItemView().getType().name().toLowerCase(Locale.ROOT).contains(q)
                        || ("#" + a.getId()).equals(q) || String.valueOf(a.getId()).equals(q))
                .sorted(sort.comparator())
                .collect(Collectors.toList());
    }

    public List<Bid> history(long auctionId) {
        try {
            return bids.findByAuction(auctionId);
        } catch (SQLException ex) {
            return List.of();
        }
    }

    public enum Sort {
        NEWEST,
        OLDEST,
        LOWEST_PRICE,
        HIGHEST_PRICE,
        ENDING_SOON;

        public Comparator<Auction> comparator() {
            return switch (this) {
                case NEWEST -> Comparator.comparingLong(Auction::getCreatedAt).reversed();
                case OLDEST -> Comparator.comparingLong(Auction::getCreatedAt);
                case LOWEST_PRICE -> Comparator.comparingDouble(Auction::getCurrentPrice);
                case HIGHEST_PRICE -> Comparator.comparingDouble(Auction::getCurrentPrice).reversed();
                case ENDING_SOON -> Comparator.comparingLong(Auction::getExpiresAt);
            };
        }
    }
}
