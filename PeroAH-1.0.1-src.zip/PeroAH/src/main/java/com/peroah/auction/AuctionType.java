package com.peroah.auction;

public enum AuctionType {
    FIXED_PRICE,
    BIDWAR;

    public static AuctionType from(String raw) {
        if (raw == null) {
            return FIXED_PRICE;
        }
        try {
            return AuctionType.valueOf(raw.trim().toUpperCase());
        } catch (IllegalArgumentException ex) {
            return FIXED_PRICE;
        }
    }
}
