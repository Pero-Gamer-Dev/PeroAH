package com.peroah.auction;

public enum AuctionStatus {
    ACTIVE,
    BIDDING,
    ENDING,
    SOLD,
    EXPIRED,
    CANCELLED,
    COMPLETED;

    public boolean isLive() {
        return this == ACTIVE || this == BIDDING || this == ENDING;
    }

    public static AuctionStatus from(String raw) {
        if (raw == null) {
            return ACTIVE;
        }
        try {
            return AuctionStatus.valueOf(raw.trim().toUpperCase());
        } catch (IllegalArgumentException ex) {
            return ACTIVE;
        }
    }
}
