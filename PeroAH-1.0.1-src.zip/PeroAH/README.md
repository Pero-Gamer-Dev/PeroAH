# PeroAH

Standalone **Auction House + BidWar** plugin for **Paper 26.2** (Java 21+).
Works with any Vault-compatible economy. No Skyblock or custom-economy dependency.

## Features

- **Fixed-price AH** — list an item, buyers purchase instantly
- **BidWar** — starting bid, minimum increment, highest bidder wins
- **Bid escrow** — bid money is withdrawn and reserved; outbid players are refunded via Auction Mail
- **Anti-snipe** — optional time extension when a bid lands near the end
- **Auction Mail** — items and money never vanish if the player is offline or the inventory is full
- **SQLite** by default, optional **MySQL / MariaDB** with HikariCP
- **Search, category filters, sort**, sell GUI, BidWar GUI, My Auctions, claim GUI
- **Taxes / listing fees**, permissions, admin tools, public API + Bukkit events

## Requirements

- Paper **26.2** (api-version `26.2`)
- Java **21+** (Paper 26.1+ servers typically run Java 25)
- [Vault](https://www.spigotmc.org/resources/vault.34315/) + any economy plugin (EssentialsX, CMI, …)

## Build

```bash
mvn -q package
```

The shaded jar is `target/PeroAH-1.0.0.jar`. Drop it in `plugins/` next to Vault.

## Commands

| Command | Description |
|---|---|
| `/ah` | Open the auction house |
| `/ah sell <price> [duration]` | List the item in hand (e.g. `50000 24h`) |
| `/ah sell bidwar <start> <increment> [duration]` | Start a BidWar (`1000 100 30m`) |
| `/ah bid <id> <amount>` | Bid on a BidWar |
| `/ah cancel <id>` | Cancel your listing (no bids on BidWars) |
| `/ah auctions` | Your live listings |
| `/ah bids` | BidWar browser |
| `/ah claim` | Auction Mail |
| `/ah search <item>` | Search |
| `/ah reload` | Reload config + messages |
| `/ahadmin remove \| inspect \| end \| clear \| reload` | Admin |

## Permissions

`auctionhouse.use`, `sell`, `bid`, `cancel`, `search`, `claim`,  
`auctionhouse.admin` (+ `remove` / `inspect` / `end` / `clear`),  
`auctionhouse.bypass.limit`, `auctionhouse.bypass.tax`, `auctionhouse.reload`.

## Configuration

See `config.yml` after first start:

- listing limits and durations
- listing fee + sale tax
- BidWar increment + anti-snipe window
- `database.type: SQLITE` or `MYSQL`

Durations accept `30s`, `15m`, `2h`, `1d`, or a raw second count.

## How money moves

1. **Fixed-price buy** — buyer is charged immediately; seller earnings go to Auction Mail (minus tax).
2. **BidWar bid** — the bid amount is withdrawn into escrow. Raising your own bid only withdraws the difference.
3. **Outbid** — previous bid is mailed back as an *Outbid Refund*.
4. **BidWar end** — escrowed winning bid is paid to the seller via mail; the item is mailed to the winner.
5. **Expire / cancel** — the item returns to the seller’s mail. Existing BidWar escrow is refunded.

Nothing is dropped on the ground except as a last-resort fallback if the database cannot store mail.

## API

```java
AuctionHouseAPI api = AuctionHouseAPI.getInstance();
api.createListing(player, item, 50000, 86400);
api.createBidWar(player, item, 1000, 100, 1800);
api.placeBid(player, auctionId, 1500);
api.getActiveListings();
api.getBidHistory(auctionId);
```

Events: `AuctionCreateEvent`, `AuctionPurchaseEvent`, `AuctionCancelEvent`,
`AuctionExpireEvent`, `BidPlaceEvent`, `BidWarEndEvent`.

## Package map

```
com.peroah
 ├── auction      Auction + lifecycle + cache
 ├── bidding      Validation + history facade
 ├── economy      Vault abstraction
 ├── storage      Hikari + SQLite/MySQL repositories
 ├── gui          Inventory menus
 ├── mail         Offline claim system
 ├── commands     /ah and /ahadmin
 ├── api          Public API + events
 └── tasks        1-second expiration processor
```
