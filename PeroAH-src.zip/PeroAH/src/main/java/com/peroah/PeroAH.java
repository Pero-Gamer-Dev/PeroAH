package com.peroah;

import com.peroah.api.AuctionHouseAPI;
import com.peroah.auction.AuctionManager;
import com.peroah.commands.AdminCommand;
import com.peroah.commands.AuctionHouseCommand;
import com.peroah.config.ConfigManager;
import com.peroah.config.Messages;
import com.peroah.economy.EconomyService;
import com.peroah.economy.EmptyEconomyProvider;
import com.peroah.economy.VaultEconomyProvider;
import com.peroah.gui.GuiManager;
import com.peroah.item.ItemValidator;
import com.peroah.listeners.InventoryListener;
import com.peroah.listeners.PlayerListener;
import com.peroah.mail.MailManager;
import com.peroah.notification.NotificationManager;
import com.peroah.storage.AuctionRepository;
import com.peroah.storage.BidRepository;
import com.peroah.storage.DatabaseManager;
import com.peroah.storage.MailRepository;
import com.peroah.storage.ReserveRepository;
import com.peroah.tasks.AuctionExpirationTask;
import org.bukkit.Bukkit;
import org.bukkit.command.PluginCommand;
import org.bukkit.plugin.java.JavaPlugin;

import java.sql.SQLException;
import java.util.logging.Level;

public final class PeroAH extends JavaPlugin {
    private static PeroAH instance;

    private ConfigManager configManager;
    private Messages messages;
    private DatabaseManager database;
    private EconomyService economy;
    private AuctionManager auctionManager;
    private GuiManager guiManager;
    private MailManager mailManager;
    private AuctionHouseAPI api;

    @Override
    public void onEnable() {
        instance = this;
        if (!getDataFolder().exists() && !getDataFolder().mkdirs()) {
            getLogger().severe("Could not create plugin data folder.");
        }

        configManager = new ConfigManager(this);
        configManager.load();
        messages = new Messages(this);
        messages.load();

        economy = VaultEconomyProvider.hook();
        if (economy == null) {
            getLogger().warning("Vault economy not found. Money operations will fail until Vault + an economy plugin are installed.");
            economy = new EmptyEconomyProvider();
        } else {
            getLogger().info("Hooked into Vault economy.");
        }

        database = new DatabaseManager(this, configManager);
        try {
            database.connect();
        } catch (SQLException ex) {
            getLogger().log(Level.SEVERE, "Could not connect to the database. Disabling PeroAH.", ex);
            Bukkit.getPluginManager().disablePlugin(this);
            return;
        }

        AuctionRepository auctionRepository = new AuctionRepository(database);
        BidRepository bidRepository = new BidRepository(database);
        ReserveRepository reserveRepository = new ReserveRepository(database);
        MailRepository mailRepository = new MailRepository(database);
        mailManager = new MailManager(mailRepository);
        NotificationManager notifications = new NotificationManager(this, configManager, messages);
        ItemValidator validator = new ItemValidator(configManager);

        auctionManager = new AuctionManager(this, configManager, economy, auctionRepository, bidRepository,
                reserveRepository, mailManager, notifications, validator);
        auctionManager.loadCache();

        guiManager = new GuiManager(this, auctionManager, configManager, messages, economy, mailManager);
        api = new AuctionHouseAPI(auctionManager);

        AuctionHouseCommand command = new AuctionHouseCommand(auctionManager, guiManager, messages, configManager, this::reloadAll);
        AdminCommand admin = new AdminCommand(auctionManager, messages, this::reloadAll);
        PluginCommand ah = getCommand("ah");
        if (ah != null) {
            ah.setExecutor(command);
            ah.setTabCompleter(command);
        }
        PluginCommand ahadmin = getCommand("ahadmin");
        if (ahadmin != null) {
            ahadmin.setExecutor(admin);
            ahadmin.setTabCompleter(admin);
        }

        Bukkit.getPluginManager().registerEvents(new InventoryListener(guiManager), this);
        Bukkit.getPluginManager().registerEvents(new PlayerListener(guiManager, mailManager, notifications), this);

        new AuctionExpirationTask(auctionManager).runTaskTimer(this, 20L, 20L);
        new com.peroah.tasks.CleanupTask(database, getLogger()).runTaskTimerAsynchronously(this, 20L * 60 * 30, 20L * 60 * 60);

        getLogger().info("PeroAH enabled. Live listings: " + auctionManager.liveListings().size());
    }

    @Override
    public void onDisable() {
        if (database != null) {
            database.shutdown();
        }
        getLogger().info("PeroAH disabled.");
    }

    public void reloadAll() {
        configManager.load();
        messages.load();
    }

    public void sync(Runnable runnable) {
        if (Bukkit.isPrimaryThread()) {
            runnable.run();
        } else {
            Bukkit.getScheduler().runTask(this, runnable);
        }
    }

    public ConfigManager configs() {
        return configManager;
    }

    public Messages messages() {
        return messages;
    }

    public EconomyService economy() {
        return economy;
    }

    public AuctionManager auctions() {
        return auctionManager;
    }

    public GuiManager guis() {
        return guiManager;
    }

    public AuctionHouseAPI api() {
        return api;
    }

    public static PeroAH get() {
        return instance;
    }
}
